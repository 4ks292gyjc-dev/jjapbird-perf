// bird.js — 로우폴리 새(짭새) 모델과 애니메이션
// 구성: 몸통 · 머리 · 부리 · 날개 2개(어깨·팔꿈치 관절) · 꼬리
// 새는 로컬 -Z 방향을 바라본다.

import * as THREE from 'three';

const COLORS = {
  body: 0x8a5a3b,
  belly: 0xead7b4,
  head: 0x6e4630,
  cheek: 0xf3ead8,
  beak: 0xf2b33d,
  eye: 0x141414,
  wingIn: 0x7a4e30,
  wingOut: 0x4a3222,
  tail: 0x5a3b27,
};

const FLAP_ANIM_TIME = 0.42; // 날갯짓 애니메이션 길이(초)

function flatMat(color, side = THREE.FrontSide) {
  return new THREE.MeshStandardMaterial({ color, flatShading: true, roughness: 0.85, side });
}

// 날개 판 하나: span 방향 = ±X, 시위 방향 = Z (앞쪽이 -Z)
function wingPanel(sign, span, rootFront, rootBack, tipFront, tipBack, thickness = 0.06) {
  const s = new THREE.Shape();
  s.moveTo(0, rootFront);
  s.lineTo(sign * span, tipFront);
  s.lineTo(sign * span, tipBack);
  s.lineTo(0, rootBack);
  s.closePath();
  const geo = new THREE.ExtrudeGeometry(s, { depth: thickness, bevelEnabled: false });
  geo.rotateX(Math.PI / 2);          // Shape 의 Y → 월드 Z, 두께는 아래(-Y) 방향
  geo.translate(0, thickness / 2, 0);
  return geo;
}

export class Bird {
  constructor() {
    this.root = new THREE.Group();   // 위치 + yaw (물리가 설정)
    this.body = new THREE.Group();   // roll / pitch (시각 연출)
    this.root.add(this.body);

    this._build();

    this.flapT = 1;                  // 0..1, 1이면 날갯짓 애니 종료
    this.flapStart = 0;
    this.flapPower = 1;
    this.wingAngle = 0.1;            // 어깨 관절 각도(+ 가 위)
    this.prevWingAngle = 0.1;
    this.elbow = 0;
    this.sweep = 0.15;               // 날개 뒤로 접힘 정도
    this.time = 0;
    this.tumble = 0;
  }

  _build() {
    const B = this.body;
    const add = (geo, color, x, y, z, sx = 1, sy = 1, sz = 1, parent = B, side) => {
      const m = new THREE.Mesh(geo, flatMat(color, side));
      m.position.set(x, y, z);
      m.scale.set(sx, sy, sz);
      m.castShadow = true;
      parent.add(m);
      return m;
    };

    // 몸통 + 배
    add(new THREE.IcosahedronGeometry(0.5, 0), COLORS.body, 0, 0, 0, 0.78, 0.7, 1.3);
    add(new THREE.IcosahedronGeometry(0.45, 0), COLORS.belly, 0, -0.12, -0.08, 0.68, 0.55, 1.05);
    // 머리
    const head = add(new THREE.IcosahedronGeometry(0.33, 0), COLORS.head, 0, 0.3, -0.68);
    add(new THREE.IcosahedronGeometry(0.2, 0), COLORS.cheek, 0, 0.22, -0.82, 1.3, 0.8, 0.8);
    // 부리
    const beak = add(new THREE.ConeGeometry(0.11, 0.34, 4), COLORS.beak, 0, 0.27, -1.05);
    beak.rotation.x = -Math.PI / 2;
    // 눈
    for (const s of [-1, 1]) add(new THREE.BoxGeometry(0.07, 0.07, 0.07), COLORS.eye, s * 0.24, 0.36, -0.86);
    this.head = head;

    // 꼬리: 부채꼴 판
    const tailShape = new THREE.Shape();
    tailShape.moveTo(-0.12, 0);
    tailShape.lineTo(0.12, 0);
    tailShape.lineTo(0.32, 0.75);
    tailShape.lineTo(0, 0.85);
    tailShape.lineTo(-0.32, 0.75);
    tailShape.closePath();
    const tailGeo = new THREE.ExtrudeGeometry(tailShape, { depth: 0.05, bevelEnabled: false });
    tailGeo.rotateX(Math.PI / 2);
    this.tail = new THREE.Group();
    this.tail.position.set(0, 0.08, 0.55);
    this.body.add(this.tail);
    add(tailGeo, COLORS.tail, 0, 0, 0, 1, 1, 1, this.tail, THREE.DoubleSide);

    // 날개: 어깨(shoulder) → 안쪽 판 → 팔꿈치(elbow) → 바깥쪽 판
    this.wings = [];
    for (const sign of [-1, 1]) {      // -1 = 왼쪽, +1 = 오른쪽
      const shoulder = new THREE.Group();
      shoulder.position.set(sign * 0.3, 0.14, -0.12);
      this.body.add(shoulder);
      const inner = new THREE.Mesh(wingPanel(sign, 0.75, -0.28, 0.38, -0.22, 0.4), flatMat(COLORS.wingIn, THREE.DoubleSide));
      inner.castShadow = true;
      shoulder.add(inner);
      const elbow = new THREE.Group();
      elbow.position.set(sign * 0.75, 0, 0);
      shoulder.add(elbow);
      const outer = new THREE.Mesh(wingPanel(sign, 0.85, -0.22, 0.4, 0.05, 0.55), flatMat(COLORS.wingOut, THREE.DoubleSide));
      outer.castShadow = true;
      elbow.add(outer);
      this.wings.push({ sign, shoulder, elbow });
    }
  }

  /** 날갯짓 1회 애니메이션 시작. strength: 0..1 */
  triggerFlap(strength = 1) {
    this.flapT = 0;
    this.flapStart = this.wingAngle;
    this.flapPower = 0.75 + 0.35 * Math.min(1, Math.max(0, strength));
  }

  /**
   * @param {number} dt
   * @param {object} s  { roll, pitch, grounded, gliding, spread, stunned, wingPose }
   *   - spread: T자 활공 자세(날개 활짝)
   *   - wingPose: 0..1 또는 null. 2단계에서 플레이어 팔 높이를 실시간으로 반영할 때 사용
   */
  update(dt, s) {
    this.time += dt;
    let target;
    let sweepTarget = 0.15;

    if (this.flapT < 1) {
      // 날갯짓: 빠르게 위로 들었다가(0~0.15) 힘차게 내려치고(0.15~0.5) 원위치(0.5~1)
      this.flapT = Math.min(1, this.flapT + dt / FLAP_ANIM_TIME);
      const t = this.flapT, up = 1.05 * this.flapPower, down = -0.75 * this.flapPower;
      if (t < 0.15) target = THREE.MathUtils.lerp(this.flapStart, up, easeOut(t / 0.15));
      else if (t < 0.5) target = THREE.MathUtils.lerp(up, down, easeInOut((t - 0.15) / 0.35));
      else target = THREE.MathUtils.lerp(down, 0.1, easeInOut((t - 0.5) / 0.5));
      sweepTarget = 0.05;
      this.wingAngle = target;
    } else {
      if (s.stunned) {
        target = Math.sin(this.time * 22) * 0.8;          // 허우적
        sweepTarget = 0.3;
      } else if (s.grounded) {
        target = 0.25;                                     // 접은 날개
        sweepTarget = 1.25;
      } else if (s.wingPose != null) {
        target = THREE.MathUtils.lerp(-0.7, 1.0, s.wingPose); // 팔 높이 → 날개 각도
        sweepTarget = 0.05;
      } else if (s.spread) {
        target = 0.02 + Math.sin(this.time * 3) * 0.015;  // T자 활공: 쫙 편 날개
        sweepTarget = 0;
      } else {
        target = 0.12 + Math.sin(this.time * 2.2) * 0.05; // 일반 활공
        sweepTarget = 0.2;
      }
      const k = 1 - Math.exp(-14 * dt);
      this.wingAngle += (target - this.wingAngle) * k;
    }

    // 팔꿈치는 어깨 움직임을 살짝 늦게 따라와 채찍처럼 휘어진다
    const vel = (this.wingAngle - this.prevWingAngle) / Math.max(dt, 1e-4);
    this.prevWingAngle = this.wingAngle;
    const elbowTarget = THREE.MathUtils.clamp(-vel * 0.045, -0.6, 0.6) + (s.grounded ? -0.4 : 0);
    this.elbow += (elbowTarget - this.elbow) * (1 - Math.exp(-18 * dt));
    this.sweep += (sweepTarget - this.sweep) * (1 - Math.exp(-10 * dt));

    for (const w of this.wings) {
      // 왼쪽 날개는 -Z 회전이 위, 오른쪽은 +Z 회전이 위 (좌우 대칭)
      w.shoulder.rotation.set(0, -w.sign * this.sweep, w.sign * this.wingAngle);
      w.elbow.rotation.set(0, -w.sign * this.sweep * 0.6, w.sign * this.elbow);
    }

    // 몸 자세: roll(선회 기울기), pitch(상승/하강), 스턴이면 빙글빙글
    if (s.stunned) this.tumble += dt * 11;
    else {
      // 스턴이 끝나면 가장 가까운 바른 자세로 되돌아온다
      this.tumble = Math.atan2(Math.sin(this.tumble), Math.cos(this.tumble));
      this.tumble *= Math.exp(-8 * dt);
    }
    this.body.rotation.order = 'YXZ';
    this.body.rotation.z = s.roll + Math.sin(this.tumble) * (s.stunned ? 0.9 : 0);
    this.body.rotation.x = s.pitch + (s.stunned ? this.tumble : 0);
    this.body.position.y = s.grounded ? 0.05 + Math.abs(Math.sin(this.time * 1.5)) * 0.02 : 0;
    this.tail.rotation.x = -s.pitch * 0.6 + (this.flapT < 1 ? Math.sin(this.flapT * Math.PI) * 0.25 : 0);
    this.head.rotation.y = s.grounded ? Math.sin(this.time * 0.9) * 0.4 : 0;
  }
}

function easeOut(t) { return 1 - (1 - t) * (1 - t); }
function easeInOut(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }
