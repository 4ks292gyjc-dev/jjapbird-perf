// pose.js — 카메라 동작 인식 (MediaPipe Pose Landmarker)
//
// main.js 의 KeyboardInput 과 같은 인터페이스를 제공한다.
//   tilt          -1(왼쪽) .. +1(오른쪽)   양 어깨(11,12)를 잇는 선의 기울기
//   glide         T자 자세(양팔을 옆으로 쭉 폄)
//   wingPose      0..1 팔 높이 → 새 날개 각도 (0.4 ≈ 수평)
//   consumeFlaps() [{ strength }]          손목(15,16)이 어깨 위에서 아래로 빠르게 내려오면 1회
//   present       사람이 제대로 보이는지 (false 면 게임이 자동 일시정지)
//
// 인식은 렌더링 루프(requestAnimationFrame)와 따로, 카메라 새 프레임마다
// 최대 POSE.FPS 번 실행한다.

// MediaPipe 버전 고정
const VISION_VERSION = '0.10.14';
const VISION_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${VISION_VERSION}/vision_bundle.mjs`;
const WASM_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${VISION_VERSION}/wasm`;
const MODEL_URL = 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task';

// ─────────────────────────────────────────────────────────────
// 조정 가능한 상수
// 길이 단위는 "어깨 너비" (사람이 카메라에서 멀든 가깝든 같은 값이 나오도록)
// ─────────────────────────────────────────────────────────────
export const POSE = {
  FPS: 30,                  // 인식 횟수 상한 (초당)
  VIDEO_WIDTH: 640,         // 카메라 해상도 (느리면 480×360 으로 낮추기)
  VIDEO_HEIGHT: 480,

  SMOOTH_RATE: 20,          // 랜드마크 지수 이동 평균 강도 (작을수록 부드럽지만 느림)
  VEL_SMOOTH_RATE: 25,      // 팔 속도 스무딩

  // 날갯짓
  ARM_UP_LEVEL: 0.1,        // 손목이 어깨선보다 이만큼 위로 올라가면 '준비' 상태 (히스테리시스 윗선)
  FLAP_SPEED: 3.0,          // 위→아래 속도가 이 값(어깨너비/초)을 넘으면 날갯짓 1회
  FLAP_SENSITIVITY: 1.0,    // 클수록 약한 동작도 날갯짓으로 인정 (임계 속도를 나눔)
  FLAP_MIN_INTERVAL: 0.15,  // 같은 동작이 두 번 세지지 않게 하는 최소 간격(초)

  // 기울기
  TILT_DEADZONE: 5,         // 도(°). 이 안쪽은 0
  TILT_MAX: 30,             // 도(°). 여기서 최대 선회
  TILT_SENSITIVITY: 1.0,    // 클수록 조금만 기울여도 많이 돈다
  TILT_SMOOTH_RATE: 12,

  // T자 활공
  TPOSE_HEIGHT: 0.55,       // 손목이 어깨 높이 ±이 범위 안에 있고
  TPOSE_SPREAD: 2.4,        // 두 손목 사이 거리가 어깨너비의 이 배수 이상이면 T자
  TPOSE_HOLD: 0.15,         // 이 시간 이상 유지해야 인정(초)

  // 인식 상태
  MIN_VISIBILITY: 0.5,      // 어깨 가시성 기준
  LOST_TIME: 0.6,           // 이 시간 동안 못 찾으면 present=false
  FOUND_TIME: 0.3,          // 이 시간 동안 찾으면 present=true

  CALIB_TIME: 3,            // 캘리브레이션 시간(초)
};

const L_SH = 11, R_SH = 12, L_EL = 13, R_EL = 14, L_WR = 15, R_WR = 16, L_HIP = 23, R_HIP = 24, NOSE = 0;
const TRACKED = [NOSE, L_SH, R_SH, L_EL, R_EL, L_WR, R_WR, L_HIP, R_HIP];
const BONES = [[L_SH, R_SH], [L_SH, L_EL], [L_EL, L_WR], [R_SH, R_EL], [R_EL, R_WR], [L_SH, L_HIP], [R_SH, R_HIP], [L_HIP, R_HIP]];

const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
const ema = (rate, dt) => 1 - Math.exp(-rate * dt);
const DEG = 180 / Math.PI;

export class PoseInput {
  constructor({ video, canvas, info }) {
    this.video = video;
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.info = info;               // 디버그 글자를 쓸 요소 (없어도 됨)

    // 공개 인터페이스
    this.tilt = 0;
    this.glide = false;
    this.wingPose = null;
    this.present = false;
    this.active = false;            // 카메라가 켜져 동작 중인가

    this._flaps = [];
    this._landmarker = null;
    this._stream = null;
    this._lastDetect = 0;
    this._lastTime = 0;

    // 스무딩된 랜드마크 { x, y, v } (x,y 는 픽셀 비율이 맞도록 보정된 값)
    this._sm = new Map();
    this._seenFor = 0;
    this._lostFor = 0;

    // 날갯짓 상태
    this._armH = 0;                 // 어깨 기준 손목 높이 (어깨너비 단위, 위가 +)
    this._armVel = 0;
    this._ready = false;            // 팔이 위에 올라가 '내려치기'를 기다리는 중
    this._peak = 0;
    this._lastFlapAt = 0;
    this._flashUntil = 0;

    this._tiltDeg = 0;
    this._tposeFor = 0;

    // 캘리브레이션 결과
    this.base = { angle: 0 };
    this.calib = null;              // 진행 중이면 { t, samples, message, done }
  }

  // ── 카메라 + 모델 준비 ──
  async start(onStatus = () => {}) {
    if (this.active) return;
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      throw new Error('카메라는 localhost 또는 https 주소에서만 쓸 수 있어요. README 의 실행 방법으로 열어주세요.');
    }

    onStatus('카메라를 켜는 중…');
    try {
      this._stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: POSE.VIDEO_WIDTH }, height: { ideal: POSE.VIDEO_HEIGHT }, facingMode: 'user' },
        audio: false,
      });
    } catch (e) {
      const msg = {
        NotAllowedError: '카메라 권한이 거부됐어요. 주소창의 카메라 아이콘에서 허용한 뒤 다시 눌러주세요.',
        NotFoundError: '연결된 카메라를 찾지 못했어요.',
        NotReadableError: '다른 프로그램이 카메라를 쓰고 있어요. 그 프로그램을 닫고 다시 눌러주세요.',
      }[e.name] || `카메라를 켜지 못했어요 (${e.name || e.message}).`;
      throw new Error(msg);
    }
    this.video.srcObject = this._stream;
    this.video.muted = true;
    this.video.playsInline = true;
    await this.video.play();

    onStatus('동작 인식 모델을 불러오는 중…');
    try {
      const vision = await import(VISION_URL);
      const fileset = await vision.FilesetResolver.forVisionTasks(WASM_URL);
      const opts = (delegate) => ({
        baseOptions: { modelAssetPath: MODEL_URL, delegate },
        runningMode: 'VIDEO',
        numPoses: 1,
        minPoseDetectionConfidence: 0.5,
        minPosePresenceConfidence: 0.5,
        minTrackingConfidence: 0.5,
      });
      try {
        this._landmarker = await vision.PoseLandmarker.createFromOptions(fileset, opts('GPU'));
      } catch {
        this._landmarker = await vision.PoseLandmarker.createFromOptions(fileset, opts('CPU'));
      }
    } catch (e) {
      this.stop();
      throw new Error('동작 인식 모델을 불러오지 못했어요. 인터넷 연결을 확인하고 다시 눌러주세요.');
    }

    this.canvas.width = this.video.videoWidth || POSE.VIDEO_WIDTH;
    this.canvas.height = this.video.videoHeight || POSE.VIDEO_HEIGHT;
    this.active = true;
    this._lastTime = performance.now();
    this._loop();
  }

  stop() {
    this.active = false;
    this._stream?.getTracks().forEach((t) => t.stop());
    this._stream = null;
    this.present = false;
  }

  // 렌더링과 분리된 인식 루프: 카메라에 새 프레임이 올 때만 돈다
  _loop() {
    if (!this.active) return;
    const next = () => this._loop();
    if (this.video.requestVideoFrameCallback) this.video.requestVideoFrameCallback(() => { this._frame(); next(); });
    else setTimeout(() => { this._frame(); next(); }, 1000 / POSE.FPS);
  }

  _frame() {
    const now = performance.now();
    if (now - this._lastDetect < 1000 / POSE.FPS - 2) return;
    this._lastDetect = now;
    const dt = Math.min(0.1, (now - this._lastTime) / 1000);
    this._lastTime = now;

    let lm = null;
    try {
      const res = this._landmarker.detectForVideo(this.video, now);
      lm = res.landmarks?.[0] || null;
    } catch (e) {
      console.warn('pose detect error', e);
    }
    this._process(lm, dt, now / 1000);
    this._draw(lm);
  }

  // ── 신호 처리 ──
  _process(lm, dt, t) {
    const W = this.canvas.width, H = this.canvas.height;
    const ok = lm && lm[L_SH].visibility > POSE.MIN_VISIBILITY && lm[R_SH].visibility > POSE.MIN_VISIBILITY;

    // 인식 여부에 히스테리시스를 둬서 한두 프레임 놓쳐도 깜빡이지 않게
    if (ok) { this._seenFor += dt; this._lostFor = 0; } else { this._lostFor += dt; this._seenFor = 0; }
    if (!this.present && this._seenFor > POSE.FOUND_TIME) this.present = true;
    if (this.present && this._lostFor > POSE.LOST_TIME) this.present = false;
    if (!ok) {
      this._ready = false;
      this.tilt += (0 - this.tilt) * ema(8, dt);
      this.glide = false;
      this.wingPose = null;
      if (this.calib && !this.calib.done) { this.calib.t = 0; this.calib.samples = []; this.calib.message = '카메라 앞에 상반신이 보이게 서주세요'; }
      return;
    }

    // 1) 랜드마크 스무딩 (지수 이동 평균). y 축을 H/W 로 보정해서 가로세로 비율을 맞춘다
    const a = ema(POSE.SMOOTH_RATE, dt);
    for (const i of TRACKED) {
      const p = lm[i];
      const x = p.x, y = p.y * (H / W), v = p.visibility ?? 1;
      const s = this._sm.get(i);
      if (!s || this._seenFor <= dt) this._sm.set(i, { x, y, v });
      else { s.x += (x - s.x) * a; s.y += (y - s.y) * a; s.v += (v - s.v) * a; }
    }
    const ls = this._sm.get(L_SH), rs = this._sm.get(R_SH);
    const lw = this._sm.get(L_WR), rw = this._sm.get(R_WR);
    const shoulderW = Math.max(0.02, Math.hypot(ls.x - rs.x, ls.y - rs.y));
    const shoulderY = (ls.y + rs.y) / 2;

    // 2) 기울기: 양 어깨를 잇는 선의 각도
    //    카메라 원본 영상에서 사용자의 왼쪽 어깨(11)는 화면 오른쪽에 있다.
    //    왼쪽으로 기울이면 왼쪽 어깨가 내려가서(y 증가) 각도가 + 가 된다.
    const angle = Math.atan2(ls.y - rs.y, ls.x - rs.x) * DEG;
    this._tiltDeg += (angle - this.base.angle - this._tiltDeg) * ema(POSE.TILT_SMOOTH_RATE, dt);
    const deg = this._tiltDeg * POSE.TILT_SENSITIVITY;
    const mag = clamp((Math.abs(deg) - POSE.TILT_DEADZONE) / (POSE.TILT_MAX - POSE.TILT_DEADZONE), 0, 1);
    this.tilt = -Math.sign(deg) * mag;            // 왼쪽 기울기 → tilt 음수(왼쪽 선회)

    // 3) 팔 높이: 어깨선 기준 두 손목 평균 높이 (어깨너비 단위, 위가 +)
    const armH = (shoulderY - (lw.y + rw.y) / 2) / shoulderW;
    if (this._seenFor <= dt) { this._armH = armH; this._armVel = 0; } // 다시 잡힌 첫 프레임은 속도 0
    const rawVel = (armH - this._armH) / Math.max(dt, 1e-3);
    this._armH = armH;
    this._armVel += (rawVel - this._armVel) * ema(POSE.VEL_SMOOTH_RATE, dt);
    this.wingPose = clamp((armH + 1.4) / 3.5, 0, 1);

    // 4) 날갯짓 판정 (히스테리시스)
    //    - 팔이 어깨선 위(ARM_UP_LEVEL)로 올라가면 '준비'
    //    - 준비 상태에서 아래로 내려가는 속도가 임계값을 넘으면 1회 세고 '준비' 해제
    //    - 다시 팔을 올리기 전까지는 세지 않는다
    if (armH > POSE.ARM_UP_LEVEL) {
      if (!this._ready) { this._ready = true; this._peak = armH; }
      this._peak = Math.max(this._peak, armH);
    }
    const downSpeed = -this._armVel;
    const threshold = POSE.FLAP_SPEED / POSE.FLAP_SENSITIVITY;
    const wristsSeen = lw.v > 0.3 && rw.v > 0.3;
    if (this._ready && wristsSeen && downSpeed > threshold && t - this._lastFlapAt > POSE.FLAP_MIN_INTERVAL) {
      // 동작 크기: 얼마나 높이서 시작했는지 + 얼마나 빨랐는지 (0..1, 상한 있음)
      const heightPart = clamp((this._peak - POSE.ARM_UP_LEVEL) / 1.2, 0, 1);
      const speedPart = clamp((downSpeed - threshold) / (threshold * 2), 0, 1);
      const strength = clamp(0.25 + heightPart * 0.45 + speedPart * 0.45, 0, 1);
      this._ready = false;
      this._lastFlapAt = t;
      this._flashUntil = t + 0.18;
      if (!this.calib || this.calib.done) this._flaps.push({ strength });
    }

    // 5) T자 활공: 손목이 어깨 높이 근처 + 양손이 옆으로 멀리
    const spread = Math.abs(lw.x - rw.x) / shoulderW;
    const levelL = Math.abs(shoulderY - lw.y) / shoulderW, levelR = Math.abs(shoulderY - rw.y) / shoulderW;
    const isT = wristsSeen && spread > POSE.TPOSE_SPREAD && levelL < POSE.TPOSE_HEIGHT && levelR < POSE.TPOSE_HEIGHT;
    this._tposeFor = isT ? this._tposeFor + dt : 0;
    this.glide = this._tposeFor > POSE.TPOSE_HOLD;

    // 6) 캘리브레이션: 똑바로 서서 팔을 내린 상태를 3초간 모은다
    if (this.calib && !this.calib.done) this._calibStep(dt, angle, armH, wristsSeen);

    if (this.info) {
      this.info.textContent = `기울기 ${this._tiltDeg.toFixed(0)}°  팔 ${armH.toFixed(1)}  ${this._ready ? '준비' : ''}`;
    }
  }

  beginCalibration() {
    this.calib = { t: 0, samples: [], message: '똑바로 서서 팔을 내려주세요', done: false };
    this._flaps = [];
  }

  _calibStep(dt, angle, armH, wristsSeen) {
    const c = this.calib;
    if (!wristsSeen) {
      c.t = 0; c.samples = [];
      c.message = '손까지 화면에 보이도록 조금 뒤로 물러나 주세요';
      return;
    }
    if (armH > -0.6) {          // 팔이 올라가 있음
      c.t = 0; c.samples = [];
      c.message = '팔을 몸 옆으로 내려주세요';
      return;
    }
    c.message = '그대로 가만히 있어주세요';
    c.t += dt;
    c.samples.push(angle);
    if (c.t >= POSE.CALIB_TIME) {
      // 평균 어깨 각도를 '똑바로 선 자세' 기준으로 저장
      const mean = c.samples.reduce((s, v) => s + v, 0) / c.samples.length;
      this.base.angle = mean;
      this._tiltDeg = 0;
      this.tilt = 0;
      c.done = true;
      c.message = '완료!';
    }
  }

  calibrationStatus() {
    if (!this.calib) return { progress: 0, message: '', done: false };
    return { progress: clamp(this.calib.t / POSE.CALIB_TIME, 0, 1), message: this.calib.message, done: this.calib.done };
  }

  update() { /* 인식은 자체 루프에서 처리 */ }

  consumeFlaps() { const f = this._flaps; this._flaps = []; return f; }

  // ── 웹캠 창에 뼈대 그리기 (캔버스는 CSS 로 좌우 반전 = 거울 모드) ──
  _draw(lm) {
    const c = this.ctx, W = this.canvas.width, H = this.canvas.height;
    c.clearRect(0, 0, W, H);
    if (!lm) return;
    const flash = performance.now() / 1000 < this._flashUntil;
    const P = (i) => [lm[i].x * W, lm[i].y * H];
    c.lineWidth = Math.max(3, W / 160);
    c.lineCap = 'round';
    c.strokeStyle = 'rgba(255,255,255,0.9)';
    for (const [a, b] of BONES) {
      if (lm[a].visibility < 0.3 || lm[b].visibility < 0.3) continue;
      const [x1, y1] = P(a), [x2, y2] = P(b);
      c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
    }
    // 어깨선: 기울기에 따라 색이 진해짐
    const [sx1, sy1] = P(L_SH), [sx2, sy2] = P(R_SH);
    c.strokeStyle = Math.abs(this.tilt) > 0 ? '#1b2340' : 'rgba(27,35,64,0.5)';
    c.lineWidth *= 1.6;
    c.beginPath(); c.moveTo(sx1, sy1); c.lineTo(sx2, sy2); c.stroke();
    // 손목: 날갯짓 준비 = 금색, 날갯짓 감지 순간 = 주황
    for (const i of [L_WR, R_WR]) {
      if (lm[i].visibility < 0.3) continue;
      const [x, y] = P(i);
      c.fillStyle = flash ? '#e8604c' : this._ready ? '#f4c542' : '#ffffff';
      c.beginPath(); c.arc(x, y, W / 40, 0, Math.PI * 2); c.fill();
    }
    const [nx, ny] = P(NOSE);
    c.strokeStyle = 'rgba(255,255,255,0.9)';
    c.lineWidth = Math.max(3, W / 160);
    c.beginPath(); c.arc(nx, ny, W / 22, 0, Math.PI * 2); c.stroke();
  }
}
