// level.js — 수직 코스, 장애물, 체크포인트, 둥지, 하늘 분위기
// 모든 오브젝트는 Three.js 기본 도형 조합(로우폴리). 외부 모델 파일 없음.
// 충돌체는 "회전 가능한 박스(OBB)"로만 표현한다. 보이는 메시와 충돌체는 분리되어 있어서
// 메시는 자유롭게 스케일해도 되고, 충돌체는 스케일 없는 Object3D 로 위치·회전만 가진다.

import * as THREE from 'three';

// ─────────────────────────────────────────────────────────────
// 코스 구성 상수
// ─────────────────────────────────────────────────────────────
export const SECTIONS = [
  { name: '도시 폐허',    from: 0,   to: 140, theme: 'city' },
  { name: '공사장',       from: 140, to: 290, theme: 'industry' },
  { name: '공중 정원',    from: 290, to: 450, theme: 'garden' },
  { name: '성층권',       from: 450, to: 620, theme: 'space' },
];
export const NEST_HEIGHT = 636;      // 둥지 바닥 높이 = 목표 높이
export const LEVEL_SEED = 20261030;  // 시드를 바꾸면 다른 코스가 생성됨

const PATH_RADIUS = 38;              // 나선 코스의 기본 반지름
const RISE_MIN = [7, 13];            // 발판 간 높이 차 [쉬움, 어려움]
const GAP_MIN = [14, 25];            // 발판 간 수평 거리 [쉬움, 어려움]

// 높이별 하늘 색 (밝은 하늘 → 노을 → 밤 → 우주)
const SKY_STOPS = [
  { h: 0,   sky: 0x9fd4f5, fog: 0xc4e5f7, sun: 0xfff1db, sunI: 2.8, hs: 0xd6ecff, hg: 0x6d5a48, hI: 1.15 },
  { h: 190, sky: 0xf3a865, fog: 0xf6c995, sun: 0xffc184, sunI: 2.3, hs: 0xffd7a8, hg: 0x5e4352, hI: 0.95 },
  { h: 330, sky: 0x8a5793, fog: 0xa77aa4, sun: 0xff9d7d, sunI: 1.6, hs: 0xe6b6d6, hg: 0x3c2d4f, hI: 0.8 },
  { h: 470, sky: 0x171b3d, fog: 0x232857, sun: 0xa9bbff, sunI: 1.1, hs: 0x6d79c9, hg: 0x1a1830, hI: 0.6 },
  { h: 640, sky: 0x020309, fog: 0x05060f, sun: 0xd8e0ff, sunI: 1.1, hs: 0x4a4f86, hg: 0x0b0b16, hI: 0.5 },
];

// ─────────────────────────────────────────────────────────────
// 유틸
// ─────────────────────────────────────────────────────────────
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const lerp = (a, b, t) => a + (b - a) * t;
const clamp01 = (x) => Math.min(1, Math.max(0, x));
const wrap01 = (x) => x - Math.floor(x);
const smoothstep = (a, b, x) => { const t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };
// 진행 방향 벡터 → yaw (새는 로컬 -Z 를 바라봄)
export const yawFromDir = (dx, dz) => Math.atan2(-dx, -dz);

// 공유 지오메트리 (메시는 scale 로 크기 조절)
const G = {
  box: new THREE.BoxGeometry(1, 1, 1),
  cyl6: new THREE.CylinderGeometry(0.5, 0.5, 1, 6),
  cyl8: new THREE.CylinderGeometry(0.5, 0.5, 1, 8),
  cone5: new THREE.ConeGeometry(0.5, 1, 5),
  cone6: new THREE.ConeGeometry(0.5, 1, 6),
  prism: new THREE.CylinderGeometry(0.5, 0.5, 1, 3), // 지붕용 삼각기둥
  ico: new THREE.IcosahedronGeometry(1, 0),
  dodeca: new THREE.DodecahedronGeometry(1, 0),
  octa: new THREE.OctahedronGeometry(1, 0),
};

const matCache = new Map();
function mat(color, emissive = 0, emissiveIntensity = 1) {
  const key = `${color}-${emissive}-${emissiveIntensity}`;
  if (!matCache.has(key)) {
    matCache.set(key, new THREE.MeshStandardMaterial({
      color, flatShading: true, roughness: 0.88, metalness: 0.05,
      emissive, emissiveIntensity,
    }));
  }
  return matCache.get(key);
}

// 구간별 팔레트
const PAL = {
  city:     { concrete: [0xb9b3a8, 0xa39d93, 0xcfc6b8], roof: [0xb4553f, 0x7d4a3a, 0x52606b], accent: [0x3f6f8f, 0xd9a441, 0x8f3f3f], rubble: 0x7b7266 },
  industry: { concrete: [0x9a9a92, 0x7f8487], roof: [0xe0a43a, 0x3d6d8f], accent: [0xd8553b, 0x2f7f6f, 0xe8b33b, 0x3a5f9a], rubble: 0x5d5752 },
  garden:   { concrete: [0xd8cdb8, 0xc7b9a0], roof: [0x5c8f4f, 0x7aa95c], accent: [0xe07a8f, 0xf2d06b, 0x8fb8e0], rubble: 0x7c6a58 },
  space:    { concrete: [0xd9dde8, 0xaab2c4], roof: [0x40508a, 0x2d3566], accent: [0x7fd6ff, 0xff9f5a, 0xc9b3ff], rubble: 0x3b3a48 },
};

// ─────────────────────────────────────────────────────────────
// Level
// ─────────────────────────────────────────────────────────────
export class Level {
  constructor(scene, seed = LEVEL_SEED) {
    this.scene = scene;
    this.root = new THREE.Group();
    scene.add(this.root);
    this.rng = mulberry32(seed);

    this.colliders = [];        // { obj, half, landable, dynamic, inv, center, radius, delta }
    this.dynamicColliders = [];
    this.animators = [];        // 매 프레임 호출되는 (t, dt) => void
    this.windZones = [];        // { box: Box3, force: Vector3, lines, ... }
    this.checkpoints = [];      // [0] = 시작 지점, [1..3] = 구간 끝
    this.nest = null;
    this.pathPoints = [];

    // 빌드 컨텍스트: 충돌체 생성 여부, 움직이는 오브젝트 여부, 그림자
    this.ctx = { collide: true, dynamic: false, shadow: true };

    this._build();

    this.root.updateMatrixWorld(true);
    for (const c of this.colliders) this._refreshCollider(c, true);
  }

  // ── 랜덤 헬퍼 ──
  r(a = 0, b = 1) { return lerp(a, b, this.rng()); }
  pick(arr) { return arr[Math.floor(this.rng() * arr.length) % arr.length]; }

  // ── 메시/충돌체 헬퍼 ──
  mesh(parent, geom, color, x, y, z, sx, sy, sz, rot = null, emissive = 0) {
    const m = new THREE.Mesh(geom, mat(color, emissive));
    m.position.set(x, y, z);
    m.scale.set(sx, sy, sz);
    if (rot) m.rotation.set(rot[0], rot[1], rot[2]);
    m.castShadow = this.ctx.shadow;
    m.receiveShadow = this.ctx.shadow;
    parent.add(m);
    return m;
  }

  collider(parent, w, h, d, x, y, z, { landable = true, rot = null } = {}) {
    if (!this.ctx.collide) return null;
    const o = new THREE.Object3D();
    o.position.set(x, y, z);
    if (rot) o.rotation.set(rot[0], rot[1], rot[2]);
    parent.add(o);
    const c = {
      obj: o,
      half: new THREE.Vector3(w / 2, h / 2, d / 2),
      landable,
      dynamic: this.ctx.dynamic,
      inv: new THREE.Matrix4(),
      center: new THREE.Vector3(),
      radius: Math.hypot(w, h, d) / 2,
      delta: new THREE.Vector3(),   // 이번 프레임 이동량 (움직이는 발판에 새를 태우는 데 사용)
      vel: new THREE.Vector3(),     // 이동 속도 (회전 날개에 맞았을 때 튕겨나가는 세기에 사용)
    };
    this.colliders.push(c);
    if (c.dynamic) this.dynamicColliders.push(c);
    return c;
  }

  // 보이는 박스 + 같은 크기의 충돌 박스
  box(parent, w, h, d, color, x, y, z, { landable = true, collide = true, rot = null, emissive = 0 } = {}) {
    const m = this.mesh(parent, G.box, color, x, y, z, w, h, d, rot, emissive);
    if (collide) this.collider(parent, w, h, d, x, y, z, { landable, rot });
    return m;
  }

  _refreshCollider(c, init = false) {
    const prev = c.center.clone();
    c.center.setFromMatrixPosition(c.obj.matrixWorld);
    c.inv.copy(c.obj.matrixWorld).invert();
    if (init) c.delta.set(0, 0, 0);
    else c.delta.subVectors(c.center, prev);
  }

  // ─────────────────────────────────────────────────────────
  // 코스 생성
  // ─────────────────────────────────────────────────────────
  _build() {
    this._buildGround();

    // 시작 지점 (체크포인트 0)
    let angle = 0;
    let y = 0;
    const start = this._pathPos(angle, y);
    const firstDir = this._pathPos(angle + 0.3, y).sub(start);
    this.checkpoints.push({
      index: 0, position: start.clone(), yaw: yawFromDir(firstDir.x, firstDir.z),
      activated: true, feather: null, beam: null, section: 0,
    });
    let prev = { pos: start.clone(), angle, yaw: 0 };
    this.pathPoints.push(start.clone());

    SECTIONS.forEach((sec, si) => {
      this._buildCentralLandmark(sec, si);
      this._buildDecor(sec);

      const isLast = si === SECTIONS.length - 1;
      const targetTop = isLast ? NEST_HEIGHT : sec.to;

      // 구간 끝(체크포인트 또는 둥지)까지 발판을 놓는다
      while (true) {
        const d = clamp01(prev.pos.y / NEST_HEIGHT); // 전체 난이도 0..1
        const riseMax = lerp(RISE_MIN[0], RISE_MIN[1], d) + 3;
        const remaining = targetTop - prev.pos.y;
        const finalHop = remaining <= riseMax + 1;
        const rise = finalHop ? remaining : lerp(RISE_MIN[0], RISE_MIN[1], d) + this.r(-2, 2.5);
        const gap = lerp(GAP_MIN[0], GAP_MIN[1], d) + this.r(-2, 3) + (finalHop ? 4 : 0);

        const radiusHere = PATH_RADIUS + Math.sin(angle * 0.7) * 9;
        angle += gap / radiusHere;
        y = prev.pos.y + rise;
        const pos = this._pathPos(angle, y);
        const dir = pos.clone().sub(prev.pos); dir.y = 0;
        const yaw = yawFromDir(dir.x, dir.z);

        // 두 발판 사이 장애물
        this._buildHazards(prev.pos, pos, sec, d, gap);

        if (finalHop) {
          if (isLast) this._buildNest(pos, yaw);
          else this._buildCheckpoint(pos, yaw, sec, si + 1);
          prev = { pos, angle, yaw };
          this.pathPoints.push(pos.clone());
          break;
        }
        this._buildPlatform(pos, yaw, sec);
        prev = { pos, angle, yaw };
        this.pathPoints.push(pos.clone());
      }
    });
  }

  _pathPos(angle, y) {
    const R = PATH_RADIUS + Math.sin(angle * 0.7) * 9;
    return new THREE.Vector3(Math.cos(angle) * R, y, Math.sin(angle) * R);
  }

  // ── 바닥: 무너진 도시 ──
  _buildGround() {
    const g = new THREE.Group();
    this.root.add(g);
    this.box(g, 340, 6, 340, 0x6f6a63, 0, -3, 0);              // 지면 (윗면 y=0)
    // 깨진 도로 판
    for (let i = 0; i < 26; i++) {
      const a = this.r(0, Math.PI * 2), rr = this.r(20, 150);
      this.box(g, this.r(6, 14), 0.4, this.r(6, 14), this.pick([0x57534e, 0x625d57, 0x4d4945]),
        Math.cos(a) * rr, 0.2, Math.sin(a) * rr, { rot: [0, this.r(0, 3), this.r(-0.05, 0.05)], landable: true });
    }
    // 낮은 폐건물 (경로 바깥쪽)
    for (let i = 0; i < 34; i++) {
      const a = this.r(0, Math.PI * 2), rr = this.r(62, 160);
      const w = this.r(6, 14), d = this.r(6, 14), h = this.r(4, 34);
      const bx = Math.cos(a) * rr, bz = Math.sin(a) * rr;
      const c = this.pick(PAL.city.concrete);
      this.box(g, w, h, d, c, bx, h / 2, bz, { rot: [0, this.r(0, 3), 0] });
      if (this.rng() < 0.5) this.box(g, w * 0.6, this.r(1, 3), d * 0.5, PAL.city.rubble, bx, h + 0.8, bz, { rot: [0, this.r(0, 3), this.r(-0.3, 0.3)] });
    }
    // 시작 지점 표시: 작은 광장
    const s = this._pathPos(0, 0);
    this.box(g, 9, 0.5, 9, 0xd9cfb8, s.x, 0.25, s.z, { landable: true });
  }

  // ── 일반 발판 ──
  _buildPlatform(pos, yaw, sec) {
    const g = new THREE.Group();
    g.position.copy(pos);
    g.rotation.y = yaw;
    this.root.add(g);
    const theme = sec.theme;
    const builders = {
      city: ['house', 'container', 'stairs', 'slab', 'rail'],
      industry: ['container', 'pipe', 'girder', 'scaffold', 'stairs'],
      garden: ['island', 'boat', 'house', 'rail', 'island'],
      space: ['asteroid', 'satellite', 'stairs', 'asteroid'],
    }[theme];
    this['_obj_' + this.pick(builders)](g, theme);
  }

  // 아래 오브젝트 빌더들은 모두 "착지면 = 로컬 y 0", 긴 축 = Z 규칙을 따른다.
  _obj_house(g, theme) {
    const P = PAL[theme];
    const w = this.r(5, 6.5), d = this.r(6, 8), h = this.r(3.5, 4.5), rh = 2;
    const top = -rh;
    this.box(g, w, h, d, this.pick(P.concrete), 0, top - h / 2, 0);
    // 박공 지붕 (삼각기둥) + 착지용 용마루 충돌체
    // 삼각기둥: 축(Y)을 -90° 눕혀 Z 방향으로, 꼭짓점이 위로 오게
    this.mesh(g, G.prism, this.pick(P.roof), 0, top + rh / 3, 0, (w * 1.15) / 0.866, d + 0.6, rh / 0.75, [-Math.PI / 2, 0, 0]);
    this.collider(g, w * 0.55, rh, d, 0, -rh / 2, 0);
    // 창문, 문, 굴뚝
    for (let i = -1; i <= 1; i += 2) this.box(g, 0.1, 1, 1.2, 0x2b3440, w / 2 + 0.03, top - h * 0.45, i * d * 0.25, { collide: false });
    this.box(g, 1.2, 2, 0.1, 0x5a3a28, 0, top - h + 1, d / 2 + 0.03, { collide: false });
    this.box(g, 0.8, 1.6, 0.8, 0x7d6b5c, w * 0.22, -0.4, -d * 0.25, { landable: false });
    // 아래 매달린 흙덩이 (떠 있는 느낌)
    this.mesh(g, G.cone6, P.rubble, 0, top - h - 2.2, 0, w * 1.1, 4.4, d * 0.9, [Math.PI, 0, 0]);
  }

  _obj_container(g, theme) {
    const P = PAL[theme];
    const col = this.pick(P.accent);
    const stack = theme === 'industry' && this.rng() < 0.5 ? 2 : 1;
    for (let s = 0; s < stack; s++) {
      const yc = -1.3 - s * 2.6;
      const rotY = s === 1 ? this.r(-0.5, 0.5) : 0;
      const c = s === 0 ? col : this.pick(P.accent);
      this.box(g, 2.6, 2.6, 7.5, c, 0, yc, 0, { rot: [0, rotY, 0] });
      // 골판 리브
      if (s === 0) for (let i = -3; i <= 3; i++) this.box(g, 2.7, 2.4, 0.15, new THREE.Color(c).multiplyScalar(0.8).getHex(), 0, yc, i * 1.05, { collide: false });
    }
  }

  _obj_stairs(g, theme) {
    const P = PAL[theme];
    const col = theme === 'space' ? 0xe6e9f2 : this.pick(P.concrete);
    const n = 5, step = 1.3;
    for (let i = 0; i < n; i++) {
      // 진행 방향(-Z)으로 올라가는 계단, 마지막 단 윗면이 y=0
      const k = n - 1 - i;
      this.box(g, 3.2, 0.6, 1.4, col, 0, -k * 0.9 - 0.3, k * step - step * (n - 1) / 2);
    }
    this.box(g, 3.2, 0.6, 2.4, col, 0, -0.3, -step * (n - 1) / 2 - 1.9);  // 꼭대기 넓은 단
    this.mesh(g, G.box, new THREE.Color(col).multiplyScalar(0.75).getHex(), 1.75, -2.0, 0, 0.3, 0.6, 7.5, [0.6, 0, 0]);
  }

  _obj_slab(g, theme) {
    const P = PAL[theme];
    const w = this.r(6, 8), d = this.r(6, 8);
    this.box(g, w, 1, d, this.pick(P.concrete), 0, -0.5, 0, { rot: [0, 0, this.r(-0.04, 0.04)] });
    // 철근
    for (let i = 0; i < 5; i++) this.mesh(g, G.box, 0x6b4a3a, this.r(-w / 2, w / 2), -1.2, d / 2 + 0.6, 0.1, 0.1, 1.6, [this.r(-0.4, 0.4), 0, 0]);
    this.mesh(g, G.dodeca, P.rubble, 0, -2.2, 0, w * 0.45, 1.8, d * 0.45);
  }

  _obj_rail(g, theme) {
    const P = PAL[theme];
    this.box(g, 3.4, 0.6, 10, P.rubble, 0, -0.9, 0, { collide: false });
    this.collider(g, 3.4, 0.6, 10, 0, -0.3, 0); // 침목 위 높이에 맞춘 착지면
    for (let z = -4.5; z <= 4.5; z += 1.1) this.mesh(g, G.box, 0x6b4f3a, 0, -0.45, z, 3, 0.25, 0.5);
    for (const x of [-0.8, 0.8]) this.mesh(g, G.box, 0x9aa0a6, x, -0.2, 0, 0.18, 0.25, 10);
    if (this.rng() < 0.45) { // 객차 한 칸
      const c = this.pick(P.accent);
      this.box(g, 2.8, 2.6, 4, c, 0, 1.3, 2.5);
      this.box(g, 2.9, 0.5, 4.1, 0xe8e2d6, 0, 2.85, 2.5, { landable: true });
    }
    if (theme === 'garden') for (let i = 0; i < 4; i++) this.mesh(g, G.ico, this.pick(P.accent), this.r(-1.6, 1.6), 0, this.r(-4, 4), 0.35, 0.35, 0.35);
  }

  _obj_pipe(g, theme) {
    const col = this.pick([0x6f8f9a, 0xb9603f, 0x8a8f5a]);
    const R = 1.3, L = 10;
    this.mesh(g, G.cyl8, col, 0, -R, 0, R * 2, L, R * 2, [Math.PI / 2, 0, 0]);
    this.collider(g, R * 1.6, R * 2, L, 0, -R, 0);
    for (const z of [-L / 2 + 0.3, 0, L / 2 - 0.3]) this.mesh(g, G.cyl8, 0x4d5257, 0, -R, z, R * 2.4, 0.5, R * 2.4, [Math.PI / 2, 0, 0]);
    // 꺾인 지선 파이프
    this.mesh(g, G.cyl8, col, 0, -R - 3.2, L * 0.3, R * 1.2, 5, R * 1.2);
  }

  _obj_girder(g) {
    const col = this.pick([0xd8553b, 0xe0a43a]);
    const L = 10;
    this.box(g, 1.8, 0.3, L, col, 0, -0.15, 0);
    this.box(g, 0.3, 1.4, L, col, 0, -1, 0, { collide: false });
    this.box(g, 1.8, 0.3, L, col, 0, -1.85, 0, { landable: false });
    // 매달린 쇠사슬 고리
    for (let i = 0; i < 4; i++) this.mesh(g, G.box, 0x555a5f, 0, -2.4 - i * 0.6, -L / 2 + 0.6, 0.15, 0.5, 0.15);
    // 가로 보 하나 (발판을 넓혀줌)
    this.box(g, 6, 0.3, 1.2, col, 0, -0.15, this.r(-2, 2));
  }

  _obj_scaffold(g) {
    const s = 4.5;
    this.box(g, s, 0.35, s, 0xb98a4a, 0, -0.18, 0);
    for (const x of [-1, 1]) for (const z of [-1, 1]) this.mesh(g, G.box, 0x9aa0a6, x * s * 0.45, -3, z * s * 0.45, 0.15, 6, 0.15);
    this.box(g, s, 0.35, s, 0xb98a4a, 0, -5.5, 0, { collide: false });
    this.mesh(g, G.box, 0x9aa0a6, 0, -2.8, s * 0.45, s * 1.2, 0.12, 0.12, [0, 0, 0.9]);  // 대각 보강재
  }

  _obj_island(g, theme) {
    const P = PAL[theme];
    const R = this.r(4, 5.5);
    this.mesh(g, G.cyl6, theme === 'space' ? 0x5c5f7a : 0x6fae55, 0, -0.5, 0, R * 2, 1, R * 2);
    this.collider(g, R * 1.5, 1, R * 1.5, 0, -0.5, 0);
    this.mesh(g, G.cone6, P.rubble, 0, -1 - R * 0.8, 0, R * 2, R * 1.6, R * 2, [Math.PI, 0, 0]);
    // 나무 또는 꽃덤불
    if (this.rng() < 0.6) {
      const tx = this.r(-R * 0.4, R * 0.4), tz = this.r(-R * 0.4, R * 0.4);
      this.mesh(g, G.cyl6, 0x6b4a33, tx, 1.2, tz, 0.5, 2.4, 0.5);
      this.mesh(g, G.ico, this.pick([0x4f8f45, 0x6aa84f, 0xe07a8f]), tx, 3.2, tz, 1.6, 1.4, 1.6);
      this.collider(g, 0.6, 2.4, 0.6, tx, 1.2, tz, { landable: false });
      this.collider(g, 2.4, 2, 2.4, tx, 3.2, tz);
    }
    for (let i = 0; i < 4; i++) this.mesh(g, G.ico, this.pick(P.accent), this.r(-R * 0.6, R * 0.6), 0.2, this.r(-R * 0.6, R * 0.6), 0.4, 0.3, 0.4);
  }

  _obj_boat(g, theme) {
    const hullC = this.pick([0xffffff, 0x2f5f8a, 0xb5463a]);
    this.box(g, 3, 1.6, 7, hullC, 0, -0.8, 0.5);
    this.box(g, 2.12, 1.6, 2.12, hullC, 0, -0.8, -3.0, { rot: [0, Math.PI / 4, 0] }); // 뾰족한 뱃머리
    this.box(g, 3.1, 0.4, 7.1, 0x5b3a26, 0, -1.8, 0.5, { collide: false });
    this.box(g, 2, 1.4, 2.6, 0xf2ead8, 0, 0.7, 2);              // 선실 (윗면도 착지 가능)
    this.mesh(g, G.cyl6, 0x8a6a4a, 0, 2.5, -1, 0.18, 5, 0.18);    // 돛대
    this.mesh(g, G.box, 0xf6f1e6, 0.1, 2.9, -0.1, 0.08, 3.2, 1.9);   // 돛
    this.collider(g, 0.3, 5, 0.3, 0, 2.5, -1, { landable: false });
  }

  _obj_asteroid(g, theme) {
    const R = this.r(3.2, 4.8);
    const m = this.mesh(g, G.dodeca, this.pick([0x6a6678, 0x585468, 0x7a6f72]), 0, -R * 0.8, 0, R, R * 0.8, R, [this.r(0, 1), this.r(0, 3), 0]);
    m.rotation.set(0, this.r(0, 3), 0);
    this.collider(g, R * 1.25, R * 1.2, R * 1.25, 0, -R * 0.6, 0);
    for (let i = 0; i < 3; i++) this.mesh(g, G.octa, 0x7fd6ff, this.r(-R / 2, R / 2), this.r(-0.2, 0.3), this.r(-R / 2, R / 2), 0.25, 0.6, 0.25, null, 0x2a6a8a);
  }

  _obj_satellite(g) {
    this.box(g, 2.6, 2.6, 3.4, 0xd9dde8, 0, -1.3, 0);
    this.box(g, 0.4, 2.2, 2.2, 0xe0b04a, 0, -1.3, -1.9, { landable: false });
    for (const x of [-1, 1]) {
      this.box(g, 5, 0.15, 2.4, 0x2d3d8a, x * 4.2, -0.6, 0, { emissive: 0x0a1030 });
      this.mesh(g, G.box, 0x9aa0a6, x * 1.6, -0.6, 0, 0.8, 0.12, 0.12);
    }
    this.mesh(g, G.cone6, 0xe6e9f2, 0, 0.6, 1, 1.8, 0.7, 1.8, [Math.PI, 0, 0]);
  }

  // ── 체크포인트: 넓은 발판 + 빛나는 깃털 + 빛기둥 ──
  _buildCheckpoint(pos, yaw, sec, index) {
    const g = new THREE.Group();
    g.position.copy(pos);
    g.rotation.y = yaw;
    this.root.add(g);
    const P = PAL[sec.theme];
    const col = this.pick(P.concrete);
    this.box(g, 12, 1.4, 12, col, 0, -0.7, 0);
    this.mesh(g, G.cone6, P.rubble, 0, -5, 0, 14, 7, 14, [Math.PI, 0, 0]);
    for (const x of [-5.5, 5.5]) for (const z of [-5.5, 5.5]) this.mesh(g, G.box, 0xf4c542, x, 0.12, z, 0.6, 0.25, 0.6, null, 0x5a3f00);

    const feather = this._makeFeather();
    feather.position.set(0, 2.4, 0);
    g.add(feather);
    const beam = this._makeBeam(0xffe08a);
    beam.position.set(0, 0, 0);
    g.add(beam);

    // 다음 방향 = 이 발판의 진행 방향
    this.checkpoints.push({
      index, position: pos.clone(), yaw, activated: false, feather, beam, section: index,
    });
  }

  _makeFeather() {
    const f = new THREE.Group();
    const vane = new THREE.Mesh(G.octa, new THREE.MeshStandardMaterial({
      color: 0xfff1b8, emissive: 0xf4c542, emissiveIntensity: 0.9, flatShading: true,
    }));
    vane.scale.set(0.55, 1.6, 0.12);
    f.add(vane);
    const shaft = new THREE.Mesh(G.cyl6, mat(0xffffff, 0xffe9a0));
    shaft.scale.set(0.08, 3.6, 0.08);
    shaft.position.y = -0.4;
    f.add(shaft);
    f.rotation.z = 0.35;
    const light = new THREE.PointLight(0xffd970, 6, 14, 1.6);
    f.add(light);
    f.userData = { vane, light };
    return f;
  }

  _makeBeam(color) {
    const m = new THREE.Mesh(
      new THREE.CylinderGeometry(1.2, 1.2, 220, 10, 1, true),
      new THREE.MeshBasicMaterial({
        color, transparent: true, opacity: 0.18, depthWrite: false,
        blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false,
      }),
    );
    m.position.y = 0;
    return m;
  }

  // ── 둥지 (최종 목적지) ──
  _buildNest(pos, yaw) {
    const g = new THREE.Group();
    g.position.copy(pos);
    g.rotation.y = yaw;
    this.root.add(g);
    // 받침 소행성
    this.mesh(g, G.dodeca, 0x4a4658, 0, -5, 0, 8, 5, 8);
    this.collider(g, 11, 2, 11, 0, -1, 0);
    // 나뭇가지 둥지: 토러스 + 잔가지
    const ring = new THREE.Mesh(new THREE.TorusGeometry(3.2, 1.1, 5, 12), mat(0x8a6234));
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.6;
    ring.castShadow = true;
    g.add(ring);
    for (let i = 0; i < 22; i++) {
      const a = (i / 22) * Math.PI * 2;
      this.mesh(g, G.box, this.pick([0x6b4a2a, 0x9a7044, 0x7b5a33]), Math.cos(a) * 3.3, 0.6 + this.r(-0.4, 0.6), Math.sin(a) * 3.3, 0.15, 0.15, this.r(2, 3.4), [this.r(-0.5, 0.5), -a + this.r(-0.4, 0.4), this.r(-0.4, 0.4)]);
    }
    this.mesh(g, G.cyl8, 0xd6b779, 0, 0.1, 0, 5, 0.3, 5);
    // 알 세 개
    for (let i = 0; i < 3; i++) this.mesh(g, G.ico, 0xf6f0e2, Math.cos(i * 2.1) * 0.9, 0.7, Math.sin(i * 2.1) * 0.9, 0.5, 0.65, 0.5);
    const light = new THREE.PointLight(0xffd970, 20, 40, 1.4);
    light.position.y = 3;
    g.add(light);
    g.add(this._makeBeam(0xfff2b0));

    this.nest = { position: pos.clone(), radius: 4.2, group: g };
  }

  // ── 두 발판 사이 장애물 ──
  _buildHazards(a, b, sec, d, gap) {
    const pHazard = lerp(0.35, 0.95, d);
    const count = this.rng() < pHazard ? (d > 0.55 && this.rng() < d - 0.3 ? 2 : 1) : 0;
    const weights = {
      city:     { mover: 3, gate: 4, wind: 3, prop: 0 },
      industry: { mover: 3.5, gate: 1.5, wind: 2, prop: 3 },
      garden:   { mover: 2.5, gate: 1.5, wind: 3, prop: 3.5 },
      space:    { mover: 3.5, gate: 1, wind: 2.5, prop: 3 },
    }[sec.theme];
    const used = new Set();
    for (let i = 0; i < count; i++) {
      let type = this._weighted(weights);
      if (type === 'gate' && gap < 16) type = 'mover';
      if (used.has(type)) continue;
      used.add(type);
      // 두 개일 때는 앞/뒤로 나눠 배치
      const t = count === 1 ? 0.5 : (i === 0 ? 0.4 : 0.62);
      const mid = a.clone().lerp(b, t);
      mid.y = lerp(a.y, b.y, t) + 1.5;
      const dir = b.clone().sub(a); dir.y = 0; dir.normalize();
      const yaw = yawFromDir(dir.x, dir.z);
      const normal = new THREE.Vector3(-dir.z, 0, dir.x);
      this['_hazard_' + type](mid, yaw, dir, normal, sec, d);
    }
  }

  _weighted(w) {
    const total = Object.values(w).reduce((s, v) => s + v, 0);
    let x = this.rng() * total;
    for (const [k, v] of Object.entries(w)) { if ((x -= v) <= 0) return k; }
    return Object.keys(w)[0];
  }

  // 좌우(또는 위아래)로 움직이는 블록 — 위에 착지하면 같이 이동한다
  _hazard_mover(mid, yaw, dir, normal, sec, d) {
    const g = new THREE.Group();
    g.position.copy(mid);
    g.rotation.y = yaw;
    this.root.add(g);
    this.ctx.dynamic = true;
    const P = PAL[sec.theme];
    const body = new THREE.Group();
    g.add(body);
    const col = this.pick(P.accent);
    if (sec.theme === 'space') this.mesh(body, G.dodeca, 0x6a6678, 0, 0, 0, 2.4, 2, 2.4);
    this.box(body, 5, 2.4, 2.6, col, 0, 0, 0, { collide: true });
    this.box(body, 5.1, 0.25, 2.7, 0x2b2b2b, 0, 1.25, 0, { collide: false });
    this.ctx.dynamic = false;

    const vertical = this.rng() < 0.25;
    const amp = vertical ? this.r(3, 5) : this.r(5, 8);
    const speed = this.r(0.7, 1.2) * (1 + d * 0.9);
    const phase = this.r(0, Math.PI * 2);
    // 로컬 X = 진행 방향의 옆
    this.animators.push((t) => {
      const s = Math.sin(t * speed + phase) * amp;
      if (vertical) body.position.set(0, s, 0); else body.position.set(s, 0, 0);
    });
  }

  // 회전하는 프로펠러 / 풍차 — 날개는 착지 불가, 부딪히면 튕겨남
  _hazard_prop(mid, yaw, dir, normal, sec, d) {
    const L = this.r(6.5, 8.5);
    const side = this.rng() < 0.5 ? -1 : 1;
    const g = new THREE.Group();
    g.position.copy(mid).addScaledVector(normal, side * L * 0.5);
    g.rotation.y = yaw;
    this.root.add(g);

    const garden = sec.theme === 'garden';
    const bladeC = garden ? 0xf2ead8 : sec.theme === 'space' ? 0xd9dde8 : 0x8f969c;
    // 풍차 몸통(정원) 또는 팬 하우징
    if (garden) {
      this.mesh(g, G.cone6, 0xe8dcc4, 0, -L * 0.75, 0.9, 2.6, L * 1.3, 2.6);
      this.collider(g, 1.6, L * 1.2, 1.6, 0, -L * 0.75, 0.9);
      this.mesh(g, G.cone6, 0x7d4a3a, 0, -0.1 + 0.3, 0.9, 2.8, 1.4, 2.8);
    } else {
      this.box(g, 1.4, 1.4, 1.8, 0x4d5257, 0, 0, 0.9, { landable: false });
    }

    this.ctx.dynamic = true;
    const spinner = new THREE.Group();
    g.add(spinner);
    this.box(spinner, 1.4, 1.4, 0.8, 0x3a3f44, 0, 0, 0, { landable: false });
    const n = garden ? 4 : 3;
    for (let i = 0; i < n; i++) {
      const arm = new THREE.Group();
      arm.rotation.z = (i / n) * Math.PI * 2;
      spinner.add(arm);
      this.box(arm, 1.3, L, 0.35, bladeC, 0, L / 2 + 0.6, 0, { landable: false });
      if (garden) this.box(arm, 1.4, L * 0.7, 0.1, 0xb5463a, 0.9, L * 0.55 + 0.6, 0, { collide: false });
    }
    this.ctx.dynamic = false;

    const speed = this.r(0.8, 1.3) * (1 + d * 0.8) * (this.rng() < 0.5 ? -1 : 1);
    this.animators.push((t, dt) => { spinner.rotation.z += speed * dt; });
  }

  // 좁은 틈: 구멍 뚫린 벽 — 돌아가면 체력이 많이 든다
  _hazard_gate(mid, yaw, dir, normal, sec, d) {
    const g = new THREE.Group();
    g.position.copy(mid);
    g.rotation.y = yaw;
    this.root.add(g);
    const W = 18, H = 16, T = 0.8;
    const hole = lerp(6, 4.2, d);
    const hx = this.r(-2.5, 2.5), hy = this.r(-1, 1.5);
    const col = { city: 0xe8e2d6, industry: 0x7f8487, garden: 0x4f8f45, space: 0xaab2c4 }[sec.theme];
    const frame = { city: 0xb5463a, industry: 0xe0a43a, garden: 0x3c6e35, space: 0x7fd6ff }[sec.theme];
    const L = -W / 2, R = W / 2, B = -H / 2, Tp = H / 2;
    const hl = hx - hole / 2, hr = hx + hole / 2, hb = hy - hole / 2, ht = hy + hole / 2;
    // 구멍을 둘러싼 4장의 판
    this.box(g, hl - L, H, T, col, (L + hl) / 2, 0, 0);
    this.box(g, R - hr, H, T, col, (hr + R) / 2, 0, 0);
    this.box(g, hole, Tp - ht, T, col, hx, (ht + Tp) / 2, 0);
    this.box(g, hole, hb - B, T, col, hx, (B + hb) / 2, 0);
    // 구멍 테두리 (눈에 잘 띄게)
    const fe = sec.theme === 'space' ? 0x1d4a66 : 0;
    this.box(g, hole + 0.6, 0.3, T + 0.2, frame, hx, ht, 0, { collide: false, emissive: fe });
    this.box(g, hole + 0.6, 0.3, T + 0.2, frame, hx, hb, 0, { collide: false, emissive: fe });
    this.box(g, 0.3, hole, T + 0.2, frame, hl, hy, 0, { collide: false, emissive: fe });
    this.box(g, 0.3, hole, T + 0.2, frame, hr, hy, 0, { collide: false, emissive: fe });
    if (sec.theme === 'city') { // 광고판 다리
      this.mesh(g, G.box, 0x6b6f73, -5, -H / 2 - 3, 0, 0.4, 6, 0.4);
      this.mesh(g, G.box, 0x6b6f73, 5, -H / 2 - 3, 0, 0.4, 6, 0.4);
    }
  }

  // 바람 구역: 옆으로 밀어내는 바람, 정원 구간에서는 가끔 상승 기류
  _hazard_wind(mid, yaw, dir, normal, sec, d) {
    const updraft = sec.theme === 'garden' && this.rng() < 0.35;
    const size = new THREE.Vector3(16, updraft ? 26 : 18, 16);
    const center = mid.clone();
    if (updraft) center.y += 6;
    const box = new THREE.Box3().setFromCenterAndSize(center, size);
    const strength = updraft ? 19 : lerp(5, 12, d);
    const force = updraft ? new THREE.Vector3(0, strength, 0)
      : normal.clone().multiplyScalar((this.rng() < 0.5 ? -1 : 1) * strength);

    // 시각화: 바람 방향으로 흐르는 선
    const N = 36;
    const pos = new Float32Array(N * 6);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const lines = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({
      color: updraft ? 0xfff2c8 : 0xffffff, transparent: true, opacity: 0.55, depthWrite: false,
    }));
    lines.frustumCulled = false;
    this.root.add(lines);
    const seeds = [];
    for (let i = 0; i < N; i++) seeds.push(new THREE.Vector3(this.rng(), this.rng(), this.rng()));
    const fdir = force.clone().normalize();
    const segLen = updraft ? 2.2 : 1.8;
    const zone = { box, force, lines };
    this.windZones.push(zone);

    const min = box.min, sz = size;
    const ax = Math.abs(fdir.x), az = Math.abs(fdir.z);
    const axis = ax > 0.5 && ax >= az ? 0 : az > 0.5 ? 2 : 1;
    this.animators.push((t) => {
      const flow = t * (strength * 0.12);
      for (let i = 0; i < N; i++) {
        const s = seeds[i];
        // 힘이 가장 큰 축으로만 시간에 따라 흐르고, 상자 안에서 순환
        let px = s.x, py = s.y, pz = s.z;
        if (axis === 0) px = wrap01(s.x + flow * Math.sign(fdir.x));
        else if (axis === 2) pz = wrap01(s.z + flow * Math.sign(fdir.z));
        else py = wrap01(s.y + flow);
        const x = min.x + px * sz.x, y = min.y + py * sz.y, z = min.z + pz * sz.z;
        pos[i * 6] = x; pos[i * 6 + 1] = y; pos[i * 6 + 2] = z;
        pos[i * 6 + 3] = x + fdir.x * segLen; pos[i * 6 + 4] = y + fdir.y * segLen; pos[i * 6 + 5] = z + fdir.z * segLen;
      }
      geo.attributes.position.needsUpdate = true;
    });
  }

  // ── 구간 중심의 거대 랜드마크 (나선 코스가 이것을 감싸고 돈다) ──
  _buildCentralLandmark(sec, si) {
    const g = new THREE.Group();
    this.root.add(g);
    if (sec.theme === 'city') {
      // 부러진 고층 빌딩
      let y = 0;
      for (let i = 0; i < 9; i++) {
        const h = 7;
        const w = 13 - i * 0.4;
        this.box(g, w, h, w, this.pick(PAL.city.concrete), this.r(-0.4, 0.4), y + h / 2, this.r(-0.4, 0.4), { rot: [0, i * 0.03, 0] });
        for (let k = 0; k < 4; k++) {
          const a = k * Math.PI / 2;
          this.mesh(g, G.box, 0x2b3440, Math.cos(a) * (w / 2 + 0.05), y + h / 2, Math.sin(a) * (w / 2 + 0.05), 0.1 + Math.abs(Math.sin(a)) * w * 0.8, 3, 0.1 + Math.abs(Math.cos(a)) * w * 0.8);
        }
        y += h;
      }
      this.box(g, 9, 3, 6, PAL.city.rubble, 2, y + 1, 0, { rot: [0.2, 0.4, 0.35] });
    } else if (sec.theme === 'industry') {
      // 떠 있는 크레인 + 천천히 도는 붐(지브) — 경로를 가로지른다
      const baseY = 170, H = 90;
      this.box(g, 3.2, H, 3.2, 0xe0a43a, 0, baseY + H / 2, 0, { landable: false });
      for (let y = baseY + 4; y < baseY + H; y += 6) this.mesh(g, G.box, 0x9a6f22, 0, y, 0, 3.4, 0.3, 3.4);
      this.box(g, 6, 1.2, 6, 0x4d5257, 0, baseY + H + 0.6, 0);
      this.ctx.dynamic = true;
      const jib = new THREE.Group();
      jib.position.set(0, baseY + H * 0.62, 0);
      g.add(jib);
      this.box(jib, 2.4, 2.2, 54, 0xe0a43a, 0, 0, -20, { landable: true });
      this.box(jib, 4, 4, 6, 0x6b6f73, 0, 0, 10);
      this.ctx.dynamic = false;
      this.animators.push((t, dt) => { jib.rotation.y += 0.12 * dt; });
    } else if (sec.theme === 'garden') {
      // 거대한 공중 섬과 나무
      const y = 370;
      this.mesh(g, G.cyl6, 0x6fae55, 0, y, 0, 26, 2, 26);
      this.collider(g, 18, 2, 18, 0, y, 0);
      this.mesh(g, G.cone6, 0x7c6a58, 0, y - 12, 0, 26, 22, 26, [Math.PI, 0, 0]);
      this.mesh(g, G.cyl6, 0x6b4a33, 0, y + 9, 0, 2.6, 18, 2.6);
      this.collider(g, 2.4, 18, 2.4, 0, y + 9, 0, { landable: false });
      for (let i = 0; i < 5; i++) {
        const a = i * 1.3;
        this.mesh(g, G.ico, this.pick([0x4f8f45, 0x6aa84f, 0x5c9a4a]), Math.cos(a) * 4, y + 18 + this.r(-2, 3), Math.sin(a) * 4, 6, 5, 6);
      }
      this.collider(g, 14, 9, 14, 0, y + 19, 0);
    } else {
      // 성층권: 떠 있는 검은 기둥(모놀리스)과 고리
      const y = 540;
      this.box(g, 5, 60, 2, 0x15161f, 0, y, 0, { landable: false });
      const ring = new THREE.Mesh(new THREE.TorusGeometry(14, 0.6, 4, 24), mat(0x7fd6ff, 0x1d4a66));
      ring.position.set(0, y, 0);
      g.add(ring);
      this.animators.push((t) => { ring.rotation.x = t * 0.15; ring.rotation.y = t * 0.1; });
    }
  }

  // ── 멀리 떠 있는 장식 (충돌 없음) ──
  _buildDecor(sec) {
    const save = { ...this.ctx };
    this.ctx.collide = false;
    this.ctx.shadow = false;
    const names = {
      city: ['house', 'container', 'slab', 'rail'],
      industry: ['container', 'pipe', 'girder'],
      garden: ['island', 'boat', 'house'],
      space: ['asteroid', 'satellite', 'asteroid'],
    }[sec.theme];
    for (let i = 0; i < 16; i++) {
      const a = this.r(0, Math.PI * 2), rr = this.r(85, 170);
      const g = new THREE.Group();
      g.position.set(Math.cos(a) * rr, this.r(sec.from + 10, sec.to + 20), Math.sin(a) * rr);
      g.rotation.set(this.r(-0.3, 0.3), this.r(0, 6), this.r(-0.3, 0.3));
      const s = this.r(2, 4);
      g.scale.set(s, s, s);
      this.root.add(g);
      this['_obj_' + this.pick(names)](g, sec.theme);
    }
    this.ctx = save;

    // 구름 (인스턴싱 1회 드로우콜) — 노을/정원 구간 아래쪽에 구름층
    if (sec.theme === 'garden' || sec.theme === 'industry') {
      const n = sec.theme === 'garden' ? 220 : 90;
      const cloud = new THREE.InstancedMesh(G.ico, new THREE.MeshStandardMaterial({ color: 0xffffff, flatShading: true, roughness: 1 }), n);
      const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), p = new THREE.Vector3(), s = new THREE.Vector3();
      const baseY = sec.theme === 'garden' ? sec.from - 10 : sec.from + 40;
      for (let i = 0; i < n; i++) {
        const a = this.r(0, Math.PI * 2), rr = this.r(15, 190);
        p.set(Math.cos(a) * rr, baseY + this.r(-8, 8), Math.sin(a) * rr);
        q.setFromEuler(new THREE.Euler(0, this.r(0, 6), 0));
        const k = this.r(3, 9);
        s.set(k * this.r(1.2, 2), k * 0.6, k);
        cloud.setMatrixAt(i, m4.compose(p, q, s));
      }
      this.root.add(cloud);
    }
  }

  // ─────────────────────────────────────────────────────────
  // 매 프레임
  // ─────────────────────────────────────────────────────────
  update(t, dt) {
    for (const fn of this.animators) fn(t, dt);
    for (const cp of this.checkpoints) {
      if (!cp.feather) continue;
      cp.feather.rotation.y = t * 1.4;
      cp.feather.position.y = 2.4 + Math.sin(t * 2 + cp.index) * 0.3;
    }
    // 움직이는 충돌체만 행렬 갱신
    for (const c of this.dynamicColliders) {
      c.obj.updateWorldMatrix(true, false);   // 부모 체인만 갱신 (전체 씬 갱신보다 저렴)
      this._refreshCollider(c);
      if (dt > 0) c.vel.copy(c.delta).divideScalar(dt);
    }
  }

  activateCheckpoint(cp) {
    cp.activated = true;
    if (cp.feather) {
      cp.feather.userData.vane.material.emissive.setHex(0xffb000);
      cp.feather.userData.vane.material.emissiveIntensity = 1.6;
      cp.feather.userData.light.intensity = 12;
    }
    if (cp.beam) cp.beam.visible = false;
  }

  resetCheckpoints() {
    for (const cp of this.checkpoints) {
      if (cp.index === 0) continue;
      cp.activated = false;
      if (cp.feather) {
        cp.feather.userData.vane.material.emissive.setHex(0xf4c542);
        cp.feather.userData.vane.material.emissiveIntensity = 0.9;
        cp.feather.userData.light.intensity = 6;
      }
      if (cp.beam) cp.beam.visible = true;
    }
  }

  sectionAt(y) {
    for (let i = SECTIONS.length - 1; i >= 0; i--) if (y >= SECTIONS[i].from) return i;
    return 0;
  }

  // 높이에 따라 하늘·안개·조명·별을 바꾼다
  updateAtmosphere(height, { scene, sun, hemi, stars }) {
    let a = SKY_STOPS[0], b = SKY_STOPS[SKY_STOPS.length - 1];
    for (let i = 0; i < SKY_STOPS.length - 1; i++) {
      if (height >= SKY_STOPS[i].h && height <= SKY_STOPS[i + 1].h) { a = SKY_STOPS[i]; b = SKY_STOPS[i + 1]; break; }
    }
    if (height > SKY_STOPS[SKY_STOPS.length - 1].h) a = b;
    const t = a === b ? 0 : smoothstep(a.h, b.h, height);
    const c = (x, y) => _tmpC.setHex(x).lerp(_tmpC2.setHex(y), t);
    scene.background.copy(c(a.sky, b.sky));
    scene.fog.color.copy(c(a.fog, b.fog));
    scene.fog.near = lerp(50, 120, clamp01(height / NEST_HEIGHT));
    scene.fog.far = lerp(290, 520, clamp01(height / NEST_HEIGHT));
    sun.color.copy(c(a.sun, b.sun));
    sun.intensity = lerp(a.sunI, b.sunI, t);
    hemi.color.copy(c(a.hs, b.hs));
    hemi.groundColor.copy(c(a.hg, b.hg));
    hemi.intensity = lerp(a.hI, b.hI, t);
    stars.material.opacity = smoothstep(360, 540, height);
    stars.visible = stars.material.opacity > 0.01;
  }
}

const _tmpC = new THREE.Color();
const _tmpC2 = new THREE.Color();
