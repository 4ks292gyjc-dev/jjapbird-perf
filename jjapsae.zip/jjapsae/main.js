// main.js — 게임 루프, 비행 물리, 충돌, 카메라, 입력 합치기
// 1단계: 키보드로 조작되는 3D 비행 + 레벨
// 2단계: pose.js(카메라 동작 인식) 연결, 캘리브레이션, 사람이 안 보이면 자동 일시정지

import * as THREE from 'three';
import { Bird } from './bird.js';
import { Level, SECTIONS, NEST_HEIGHT } from './level.js';
import { UI } from './ui.js';
import { PoseInput } from './pose.js';

// ─────────────────────────────────────────────────────────────
// 조정 가능한 상수 (단위: m, 초, m/s, m/s²)
// ─────────────────────────────────────────────────────────────
export const CONFIG = {
  // 날갯짓
  FLAP_UP: 8.0,              // 날갯짓 1회에 더해지는 상승 속도
  FLAP_FORWARD: 2.0,         // 날갯짓 1회에 더해지는 전진 속도
  FLAP_MIN_SCALE: 0.7,       // 동작이 작을 때(strength=0) 힘 배율
  FLAP_MAX_SCALE: 1.25,      // 동작이 클 때(strength=1) 힘 배율 = 상한
  FLAP_FALL_DAMP: 0.4,       // 떨어지는 중 날갯짓하면 하강 속도를 이 비율로 줄인 뒤 힘을 더함
  FLAP_COOLDOWN: 0.12,       // 너무 빠른 연타 방지(초)

  // 중력·공기
  GRAVITY: 11,
  AIR_DRAG_H: 0.6,           // 수평 공기 저항 (클수록 빨리 멈춤)
  AIR_DRAG_V: 0.6,           // 수직 공기 저항
  LATERAL_GRIP: 1.2,         // 옆으로 미끄러지는 속도를 줄이는 정도
  MAX_H_SPEED: 16,
  MAX_RISE_SPEED: 11,
  MAX_FALL_SPEED: 30,

  // 활공 (날갯짓을 멈추면)
  GLIDE_DELAY: 0.35,         // 마지막 날갯짓 후 이 시간이 지나면 활공 상태
  GLIDE_FALL_SPEED: 5.5,     // 활공 중 최대 하강 속도
  TPOSE_FALL_SPEED: 2.4,     // T자 자세(Shift) 활공 중 최대 하강 속도
  GLIDE_BRAKE: 3,            // 하강 속도를 활공 속도로 줄이는 빠르기
  GLIDE_MIN_FORWARD: 6,      // 활공 중 유지하려는 최소 전진 속도
  GLIDE_FORWARD_ACCEL: 4,

  // 선회
  TURN_RATE: 1.9,            // 최대 기울기에서의 회전 속도(rad/s)
  TURN_CARRY: 0.85,          // 회전할 때 속도 방향도 같이 돌리는 비율
  GROUND_TURN_FACTOR: 1.3,   // 발판 위에서 제자리 회전 배율
  MAX_ROLL: 0.75,            // 새 모델의 최대 roll 각도(rad)

  // 충돌·착지
  BIRD_RADIUS: 0.55,
  LAND_NORMAL_Y: 0.6,        // 충돌면 법선의 y가 이보다 크면 '윗면' = 착지
  GROUND_FRICTION: 9,
  BOUNCE: 0.45,              // 옆/아랫면 충돌 반발 계수
  KNOCKBACK: 6,              // 충돌 시 추가로 튕겨내는 속도
  STUN_MIN_IMPACT: 2.5,      // 이 속도 이상으로 부딪혀야 스턴
  STUN_TIME: 0.9,            // 스턴(조작 불가) 시간

  // 체력: 날갯짓마다 소모, 발판에서 쉬면 회복 → 발판을 징검다리처럼 쓰게 만든다
  STAMINA_ENABLED: true,
  STAMINA_MAX: 100,
  STAMINA_FLAP_COST: 15,
  STAMINA_REGEN_GROUND: 70,  // 초당 회복(발판 위)
  STAMINA_REGEN_AIR: 3,      // 초당 회복(공중)
  STAMINA_EMPTY_SCALE: 0.3,  // 체력이 없을 때 날갯짓 힘 배율

  // 추락·체크포인트
  FALL_COUNT_HEIGHT: 18,     // 이만큼 떨어지면 '추락 1회'
  FALL_RESET_DEPTH: 40,      // 마지막 체크포인트보다 이만큼 아래로 떨어지면 그곳으로 복귀
  WORLD_RADIUS: 190,         // 이 반경 밖으로 나가면 안쪽으로 밀어냄

  // 카메라
  CAM_DISTANCE: 9,
  CAM_HEIGHT: 3.2,
  CAM_POS_LERP: 4,           // 위치 추적 속도 (작을수록 늦게 따라옴)
  CAM_YAW_LERP: 2.6,         // 선회 추적 속도 (작을수록 선회 시 더 늦게 돌아옴)
  CAM_LOOK_AHEAD: 5,
  BASE_FOV: 64,
  SPEED_FOV: 12,             // 빠를수록 시야각이 넓어져 속도감

  // 키보드
  KEY_TILT_RATE: 3.5,        // 키를 누르고 있을 때 기울기가 차오르는 속도
  KEY_FLAP_STRENGTH: 0.75,   // 키보드 날갯짓의 동작 크기(0..1)

  DEBUG: true,               // 숫자키 1~4 = 해당 구간 시작점으로 이동
};

const STEP = 1 / 120;        // 물리 고정 스텝 (빠른 속도에서도 장애물을 뚫지 않게)
const UP = new THREE.Vector3(0, 1, 0);

const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
const damp = (k, dt) => 1 - Math.exp(-k * dt);
const lerpAngle = (a, b, t) => a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * t;

// ─────────────────────────────────────────────────────────────
// 입력 인터페이스 (KeyboardInput / 2단계의 PoseInput 공통)
//   tilt      : -1(왼쪽) .. +1(오른쪽)
//   glide     : T자 활공 자세 여부
//   wingPose  : 0..1 팔 높이 (없으면 null)
//   consumeFlaps(): 지난 프레임 이후 감지된 날갯짓 [{ strength: 0..1 }]
// ─────────────────────────────────────────────────────────────
class KeyboardInput {
  constructor() {
    this.tilt = 0;
    this.glide = false;
    this.wingPose = null;
    this._flaps = [];
    this._left = false;
    this._right = false;

    addEventListener('keydown', (e) => {
      if (e.code === 'Space') {
        e.preventDefault();
        if (!e.repeat) this._flaps.push({ strength: CONFIG.KEY_FLAP_STRENGTH });
      }
      if (e.code === 'KeyA' || e.code === 'ArrowLeft') this._left = true;
      if (e.code === 'KeyD' || e.code === 'ArrowRight') this._right = true;
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') this.glide = true;
    });
    addEventListener('keyup', (e) => {
      if (e.code === 'KeyA' || e.code === 'ArrowLeft') this._left = false;
      if (e.code === 'KeyD' || e.code === 'ArrowRight') this._right = false;
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') this.glide = false;
    });
    addEventListener('blur', () => { this._left = this._right = this.glide = false; });
  }

  // 키는 0/1 이지만, 몸 기울이기처럼 서서히 차오르게 만든다
  update(dt) {
    const target = (this._right ? 1 : 0) - (this._left ? 1 : 0);
    const step = CONFIG.KEY_TILT_RATE * dt;
    this.tilt += clamp(target - this.tilt, -step, step);
  }

  consumeFlaps() { const f = this._flaps; this._flaps = []; return f; }
}

// 키보드와 카메라 입력을 하나로 합친다. 키보드를 누르고 있으면 키보드가 우선
class MergedInput {
  constructor(kb, pose) { this.kb = kb; this.pose = pose; }
  update(dt) { this.kb.update(dt); this.pose.update(dt); }
  get tilt() {
    if (Math.abs(this.kb.tilt) > 0.02 || !this.pose.active) return this.kb.tilt;
    return this.pose.tilt;
  }
  get glide() { return this.kb.glide || (this.pose.active && this.pose.glide); }
  get wingPose() { return this.pose.active && this.pose.present ? this.pose.wingPose : null; }
  consumeFlaps() { return [...this.kb.consumeFlaps(), ...this.pose.consumeFlaps()]; }
}

// 재사용 벡터 (가비지 줄이기)
const _fwd = new THREE.Vector3(), _right = new THREE.Vector3();
const _local = new THREE.Vector3(), _closest = new THREE.Vector3(), _diff = new THREE.Vector3();
const _n = new THREE.Vector3(), _rel = new THREE.Vector3();
const _off = new THREE.Vector3(), _desired = new THREE.Vector3(), _look = new THREE.Vector3();

// ─────────────────────────────────────────────────────────────
class Game {
  constructor() {
    // 렌더러
    const canvas = document.getElementById('game');
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    this.renderer.setSize(innerWidth, innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x9fd4f5);
    this.scene.fog = new THREE.Fog(0xc4e5f7, 50, 290);
    this.camera = new THREE.PerspectiveCamera(CONFIG.BASE_FOV, innerWidth / innerHeight, 0.1, 1500);

    // 조명: 반구광 + 그림자 있는 태양 1개 (새를 따라다님)
    this.hemi = new THREE.HemisphereLight(0xd6ecff, 0x6d5a48, 1.1);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff1db, 2.8);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1024, 1024);
    const sc = this.sun.shadow.camera;
    sc.left = -24; sc.right = 24; sc.top = 24; sc.bottom = -24; sc.near = 1; sc.far = 150;
    this.sun.shadow.bias = -0.0006;
    this.sun.shadow.normalBias = 0.03;
    this.sunOffset = new THREE.Vector3(18, 60, 12); // 거의 위에서 → 그림자가 착지 지점을 알려줌
    this.scene.add(this.sun, this.sun.target);

    this.stars = this._makeStars();
    this.scene.add(this.stars);

    this.level = new Level(this.scene);
    this.bird = new Bird();
    this.scene.add(this.bird.root);

    this.pose = new PoseInput({
      video: document.getElementById('cam-video'),
      canvas: document.getElementById('cam-canvas'),
      info: document.getElementById('cam-info'),
    });
    this.input = new MergedInput(new KeyboardInput(), this.pose);
    this.mode = 'keyboard';            // 'keyboard' | 'camera'
    this.ctrl = { tilt: 0, glide: false };
    this.afterCalib = null;
    this.backFor = 0;                  // 자동 일시정지 후 사람이 다시 보인 시간

    this.ui = new UI({
      onStartCamera: () => this.startCamera(),
      onStartKeyboard: () => { this.mode = 'keyboard'; this.start(); },
      onResume: () => this.resume(),
      onRestart: () => this.start(),
      onRecalibrate: () => this.beginCalibration(() => this.resume()),
    });
    this.ui.setCheckpointMarks(this.level.checkpoints.slice(1).map((c) => c.position.y / NEST_HEIGHT));

    // 물리 상태
    this.p = {
      pos: new THREE.Vector3(), vel: new THREE.Vector3(),
      yaw: 0, roll: 0, pitch: 0,
      stun: 0, grounded: false, ground: null,
      gliding: false, spread: false,
      stamina: CONFIG.STAMINA_MAX, lastFlap: -10,
      airPeak: 0, fallCounted: false,
    };
    this.simTime = 0;
    this.levelTime = 0;
    this.acc = 0;
    this.stats = { time: 0, falls: 0 };
    this.cpIndex = 0;
    this.maxSection = 0;
    this.camYaw = 0;
    this.camLook = new THREE.Vector3();
    this.shake = 0;
    this.state = 'menu';

    this.respawn(0);
    this.clock = new THREE.Clock();

    addEventListener('resize', () => this._resize());
    addEventListener('keydown', (e) => this._onKey(e));
    document.addEventListener('visibilitychange', () => { if (document.hidden && this.state === 'playing') this.pause(); });

    this.ui.show('menu');
    this.ui.setCamVisible(false);
    this.renderer.setAnimationLoop(() => this.tick());
  }

  _makeStars() {
    const N = 2400, pos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const u = Math.random() * 2 - 1, a = Math.random() * Math.PI * 2, r = 900;
      const s = Math.sqrt(1 - u * u);
      pos[i * 3] = Math.cos(a) * s * r; pos[i * 3 + 1] = u * r; pos[i * 3 + 2] = Math.sin(a) * s * r;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    return new THREE.Points(g, new THREE.PointsMaterial({
      color: 0xffffff, size: 2, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false, fog: false,
    }));
  }

  _resize() {
    this.camera.aspect = innerWidth / innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(innerWidth, innerHeight);
  }

  _onKey(e) {
    if (e.code === 'Escape' || e.code === 'KeyP') {
      if (this.state === 'playing') this.pause();
      else if (this.state === 'paused') this.resume();
    }
    if (e.code === 'Enter' && this.state === 'menu') { this.mode = 'keyboard'; this.start(); }
    if (e.code === 'Enter' && this.state === 'clear') this.start();
    if (this.state !== 'playing') return;
    if (e.code === 'KeyR') { this.respawn(this.cpIndex); this.ui.toast('체크포인트로 돌아왔어요'); }
    if (CONFIG.DEBUG && /^Digit[1-4]$/.test(e.code)) {
      const idx = Number(e.code.slice(5)) - 1;          // 0..3
      for (const cp of this.level.checkpoints) if (cp.index > 0 && cp.index <= idx) this.level.activateCheckpoint(cp);
      this.cpIndex = idx;
      this.maxSection = idx;
      this.respawn(idx);
      this.ui.toast(`디버그: ${idx + 1}구간 시작점`);
    }
  }

  // ── 게임 흐름 ──
  start() {
    this.level.resetCheckpoints();
    this.stats = { time: 0, falls: 0 };
    this.cpIndex = 0;
    this.maxSection = 0;
    this.respawn(0);
    this.state = 'playing';
    this.ui.show('hud');
    this.ui.showSection(SECTIONS[0].name, 0);
    this.clock.getDelta();
  }

  pause() { this.state = 'paused'; this.ui.show('pause', { camera: this.mode === 'camera' }); }
  resume() {
    if (this.mode === 'camera' && !this.pose.present) { this.goAway(); return; }
    this.state = 'playing';
    this.ui.show('hud');
    this.input.consumeFlaps();          // 일시정지 중 쌓인 동작은 버린다
    this.clock.getDelta();
  }

  // ── 카메라 모드 ──
  async startCamera() {
    this.state = 'loading';
    this.ui.show('loading');
    try {
      await this.pose.start((msg) => this.ui.setLoading(msg));
    } catch (e) {
      this.state = 'menu';
      this.ui.show('menu');
      this.ui.showCameraError(e.message);
      return;
    }
    this.mode = 'camera';
    this.ui.setCamVisible(true);
    this.beginCalibration(() => this.start());
  }

  beginCalibration(after) {
    this.calibInGame = this.state === 'paused';
    this.afterCalib = after;
    this.state = 'calibrating';
    this.pose.beginCalibration();
    this.ui.show('calib');
  }

  // 사람이 화면에서 사라지면 자동 일시정지
  goAway() {
    this.state = 'away';
    this.backFor = 0;
    this.ui.show('away');
  }

  clear() {
    this.state = 'clear';
    const n = this.level.nest.position;
    this.p.pos.set(n.x, n.y + 0.9, n.z);
    this.p.vel.set(0, 0, 0);
    this.ui.showClear(this.stats);
  }

  respawn(idx) {
    const cp = this.level.checkpoints[idx];
    const p = this.p;
    p.pos.copy(cp.position).add(new THREE.Vector3(0, 1.6, 0));
    p.vel.set(0, 0, 0);
    p.yaw = cp.yaw;
    p.stun = 0;
    p.grounded = false;
    p.ground = null;
    p.stamina = CONFIG.STAMINA_MAX;
    p.airPeak = p.pos.y;
    p.fallCounted = false;
    this.camYaw = cp.yaw;
    _off.set(0, CONFIG.CAM_HEIGHT, CONFIG.CAM_DISTANCE).applyAxisAngle(UP, this.camYaw);
    this.camera.position.copy(p.pos).add(_off);
    this.camLook.copy(p.pos);
  }

  // ── 날갯짓 1회: 위 + 앞으로 힘 ──
  flap(strength) {
    const C = CONFIG, p = this.p;
    if (p.stun > 0) return;
    if (this.simTime - p.lastFlap < C.FLAP_COOLDOWN) return;

    // 동작 크기(strength)에 따라 힘이 커지되 상한(FLAP_MAX_SCALE)이 있다
    let scale = THREE.MathUtils.lerp(C.FLAP_MIN_SCALE, C.FLAP_MAX_SCALE, clamp(strength, 0, 1));
    if (C.STAMINA_ENABLED) {
      if (p.stamina >= C.STAMINA_FLAP_COST) p.stamina -= C.STAMINA_FLAP_COST;
      else { scale *= C.STAMINA_EMPTY_SCALE; p.stamina = 0; }
    }
    if (p.vel.y < 0) p.vel.y *= C.FLAP_FALL_DAMP;       // 떨어지던 중이면 하강을 먼저 꺾어준다
    p.vel.y += C.FLAP_UP * scale;
    _fwd.set(-Math.sin(p.yaw), 0, -Math.cos(p.yaw));
    p.vel.addScaledVector(_fwd, C.FLAP_FORWARD * scale);
    if (p.grounded) { p.grounded = false; p.ground = null; p.pos.y += 0.05; } // 이륙

    p.lastFlap = this.simTime;
    this.bird.triggerFlap(strength);
    this.ui.flashFlap(scale < C.FLAP_MIN_SCALE);
  }

  // ── 고정 스텝 비행 물리 ──
  step(dt) {
    const C = CONFIG, p = this.p;
    this.simTime += dt;
    const stunned = p.stun > 0;
    if (stunned) p.stun = Math.max(0, p.stun - dt);
    const tilt = stunned ? 0 : this.ctrl.tilt;

    // 1) 선회: 기울기에 비례한 yaw 회전. 왼쪽(-) 기울기 → 왼쪽으로 돈다
    const turn = -tilt * C.TURN_RATE * (p.grounded ? C.GROUND_TURN_FACTOR : 1) * dt;
    p.yaw += turn;
    if (!p.grounded) {
      // 수평 속도도 같이 돌려 '기울여서 도는' 느낌을 준다
      const a = turn * C.TURN_CARRY, cs = Math.cos(a), sn = Math.sin(a);
      const vx = p.vel.x, vz = p.vel.z;
      p.vel.x = vx * cs + vz * sn;
      p.vel.z = -vx * sn + vz * cs;
    }
    _fwd.set(-Math.sin(p.yaw), 0, -Math.cos(p.yaw));
    _right.set(Math.cos(p.yaw), 0, -Math.sin(p.yaw));

    // 2) 중력
    p.vel.y -= C.GRAVITY * dt;

    // 3) 바람 구역
    for (const z of this.level.windZones) if (z.box.containsPoint(p.pos)) p.vel.addScaledVector(z.force, dt);

    // 4) 활공: 날갯짓을 쉬면 하강 속도를 제한하고 앞으로 미끄러진다. T자 자세면 더 천천히
    const gliding = !p.grounded && !stunned && this.simTime - p.lastFlap > C.GLIDE_DELAY;
    p.gliding = gliding;
    p.spread = gliding && this.ctrl.glide;
    if (gliding) {
      const maxFall = this.ctrl.glide ? C.TPOSE_FALL_SPEED : C.GLIDE_FALL_SPEED;
      if (p.vel.y < -maxFall) p.vel.y += (-maxFall - p.vel.y) * damp(C.GLIDE_BRAKE, dt);
      if (p.vel.dot(_fwd) < C.GLIDE_MIN_FORWARD) p.vel.addScaledVector(_fwd, C.GLIDE_FORWARD_ACCEL * dt);
    }

    // 5) 공기 저항
    const dh = Math.exp(-C.AIR_DRAG_H * dt);
    p.vel.x *= dh; p.vel.z *= dh;
    p.vel.y *= Math.exp(-C.AIR_DRAG_V * dt);

    // 6) 옆미끄럼 감쇠 (스턴 중에는 튕겨나가는 힘을 살린다)
    if (!stunned) p.vel.addScaledVector(_right, -p.vel.dot(_right) * damp(C.LATERAL_GRIP, dt));

    // 7) 발판 위 마찰
    if (p.grounded) { const f = Math.exp(-C.GROUND_FRICTION * dt); p.vel.x *= f; p.vel.z *= f; }

    // 8) 속도 제한
    const hs = Math.hypot(p.vel.x, p.vel.z);
    if (hs > C.MAX_H_SPEED) { p.vel.x *= C.MAX_H_SPEED / hs; p.vel.z *= C.MAX_H_SPEED / hs; }
    p.vel.y = clamp(p.vel.y, -C.MAX_FALL_SPEED, C.MAX_RISE_SPEED);

    // 9) 적분 + 충돌
    p.pos.addScaledVector(p.vel, dt);
    this.collide();

    // 10) 맵 경계: 너무 멀리 가면 부드럽게 안쪽으로
    const r = Math.hypot(p.pos.x, p.pos.z);
    if (r > C.WORLD_RADIUS) {
      p.vel.x -= (p.pos.x / r) * 25 * dt;
      p.vel.z -= (p.pos.z / r) * 25 * dt;
    }

    // 11) 체력 회복
    p.stamina = Math.min(C.STAMINA_MAX, p.stamina + (p.grounded ? C.STAMINA_REGEN_GROUND : C.STAMINA_REGEN_AIR) * dt);

    // 12) 추락 판정: 마지막으로 서 있던/가장 높았던 지점에서 크게 떨어지면 1회
    if (p.grounded) { p.airPeak = p.pos.y; p.fallCounted = false; }
    else {
      p.airPeak = Math.max(p.airPeak, p.pos.y);
      if (!p.fallCounted && this.state === 'playing' && p.airPeak - p.pos.y > C.FALL_COUNT_HEIGHT) {
        p.fallCounted = true;
        this.stats.falls++;
        this.ui.toast('추락!', 'warn');
      }
    }
  }

  // ── 구(새) vs 회전 박스(OBB) 충돌 ──
  collide() {
    const C = CONFIG, p = this.p, r = C.BIRD_RADIUS;
    let ground = null;
    p.grounded = false;
    for (const c of this.level.colliders) {
      // 대략 판정: 경계 구끼리 멀면 건너뜀
      const dx = p.pos.x - c.center.x, dy = p.pos.y - c.center.y, dz = p.pos.z - c.center.z;
      const rr = c.radius + r;
      if (dx * dx + dy * dy + dz * dz > rr * rr) continue;

      // 박스 로컬 좌표에서 가장 가까운 점
      _local.copy(p.pos).applyMatrix4(c.inv);
      const h = c.half;
      _closest.set(clamp(_local.x, -h.x, h.x), clamp(_local.y, -h.y, h.y), clamp(_local.z, -h.z, h.z));
      _diff.subVectors(_local, _closest);
      const d2 = _diff.lengthSq();
      if (d2 >= r * r) continue;

      let pen;
      if (d2 > 1e-10) {
        const d = Math.sqrt(d2);
        _n.copy(_diff).divideScalar(d);
        pen = r - d;
      } else {
        // 중심이 박스 안에 들어감: 가장 가까운 면 쪽으로 밀어낸다
        const ex = h.x - Math.abs(_local.x), ey = h.y - Math.abs(_local.y), ez = h.z - Math.abs(_local.z);
        if (ey <= ex && ey <= ez) { _n.set(0, Math.sign(_local.y) || 1, 0); pen = ey + r; }
        else if (ex <= ez) { _n.set(Math.sign(_local.x) || 1, 0, 0); pen = ex + r; }
        else { _n.set(0, 0, Math.sign(_local.z) || 1); pen = ez + r; }
      }
      _n.transformDirection(c.obj.matrixWorld);       // 월드 법선
      p.pos.addScaledVector(_n, pen);

      if (_n.y > C.LAND_NORMAL_Y && c.landable) {
        // 윗면 → 착지 (움직이는 발판은 main 루프에서 delta 만큼 같이 이동)
        const vn = p.vel.dot(_n);
        if (vn < 0) p.vel.addScaledVector(_n, -vn);
        p.grounded = true;
        ground = c;
        if (p.stun > 0.25) p.stun = 0.25;              // 착지하면 스턴이 빨리 풀린다
      } else {
        // 옆면·아랫면 → 튕겨나감 + 스턴. 움직이는 장애물의 속도를 고려한 상대 속도로 판정
        _rel.subVectors(p.vel, c.vel);
        const vn = _rel.dot(_n);
        if (vn < 0) {
          p.vel.addScaledVector(_n, -(1 + C.BOUNCE) * vn);
          if (-vn > C.STUN_MIN_IMPACT && p.stun <= 0) {
            p.vel.addScaledVector(_n, C.KNOCKBACK);
            p.stun = C.STUN_TIME;
            this.shake = 0.35;
            this.ui.flashHit();
          }
        }
      }
    }
    p.ground = ground;
  }

  // ── 체크포인트·둥지·복귀 ──
  checkProgress() {
    const p = this.p;
    for (const cp of this.level.checkpoints) {
      if (cp.activated) continue;
      const dx = p.pos.x - cp.position.x, dz = p.pos.z - cp.position.z, dy = p.pos.y - cp.position.y;
      if (dx * dx + dz * dz < 7.5 * 7.5 && dy > -1 && dy < 4.5) {
        this.level.activateCheckpoint(cp);
        if (cp.index > this.cpIndex) this.cpIndex = cp.index;
        p.stamina = CONFIG.STAMINA_MAX;
        this.ui.toast(`체크포인트 ${cp.index} / ${this.level.checkpoints.length - 1}`, 'gold');
      }
    }

    const n = this.level.nest.position;
    const ndx = p.pos.x - n.x, ndz = p.pos.z - n.z;
    if (ndx * ndx + ndz * ndz < (this.level.nest.radius + 0.5) ** 2 && p.pos.y > n.y - 0.5 && p.pos.y < n.y + 4) {
      this.clear();
      return;
    }

    const floor = this.level.checkpoints[this.cpIndex].position.y - CONFIG.FALL_RESET_DEPTH;
    if (p.pos.y < floor || p.pos.y < -40) {
      if (!p.fallCounted) this.stats.falls++;
      this.respawn(this.cpIndex);
      this.ui.toast('체크포인트에서 다시 시작해요', 'warn');
    }

    const si = this.level.sectionAt(p.pos.y);
    if (si > this.maxSection) {
      this.maxSection = si;
      this.ui.showSection(SECTIONS[si].name, si);
    }
  }

  // ── 3인칭 추적 카메라 ──
  updateCamera(dt) {
    const C = CONFIG, p = this.p;
    // yaw 를 천천히 따라가서, 선회할 때 카메라가 살짝 늦게 돌아온다
    this.camYaw = lerpAngle(this.camYaw, p.yaw, damp(C.CAM_YAW_LERP, dt));
    // 떨어질수록 카메라를 위로 올려 아래(착지할 곳)가 보이게
    const fall = clamp(-p.vel.y / 14, 0, 1);
    _off.set(0, C.CAM_HEIGHT + fall * 4, C.CAM_DISTANCE + fall * 2).applyAxisAngle(UP, this.camYaw);
    _desired.copy(p.pos).add(_off);
    this.camera.position.lerp(_desired, damp(C.CAM_POS_LERP, dt));

    _look.set(-Math.sin(this.camYaw), 0, -Math.cos(this.camYaw))
      .multiplyScalar(C.CAM_LOOK_AHEAD * (1 - fall * 0.7)).add(p.pos);
    _look.y += 1 - fall * 2.5;
    this.camLook.lerp(_look, damp(10, dt));
    this.camera.lookAt(this.camLook);
    this.camera.rotateZ(p.roll * 0.12);                // 새와 함께 살짝 기울기

    if (this.shake > 0) {
      const s = this.shake * 0.6;
      this.camera.position.x += (Math.random() - 0.5) * s;
      this.camera.position.y += (Math.random() - 0.5) * s;
      this.shake = Math.max(0, this.shake - dt);
    }

    const speed = Math.hypot(p.vel.x, p.vel.z);
    const fov = C.BASE_FOV + C.SPEED_FOV * clamp(speed / C.MAX_H_SPEED, 0, 1);
    if (Math.abs(this.camera.fov - fov) > 0.05) {
      this.camera.fov += (fov - this.camera.fov) * damp(3, dt);
      this.camera.updateProjectionMatrix();
    }
  }

  // 메뉴·클리어 화면용 천천히 도는 카메라
  orbitCamera(center, radius, height, lookUp, dt) {
    const a = this.levelTime * 0.09;
    _desired.set(center.x + Math.cos(a) * radius, center.y + height, center.z + Math.sin(a) * radius);
    this.camera.position.lerp(_desired, damp(2, dt));
    _look.copy(center); _look.y += lookUp;
    this.camLook.lerp(_look, damp(2, dt));
    this.camera.lookAt(this.camLook);
  }

  // 메뉴·로딩·클리어 화면: 레벨은 움직이고 카메라는 천천히 돈다
  _attract(dt) {
    this.ctrl.tilt = 0;
    this.ctrl.glide = false;
    this.levelTime += dt;
    this.level.update(this.levelTime, dt);
    if (this.state === 'clear') {
      this.orbitCamera(this.level.nest.position, 13, 5, 1, dt);
    } else {
      this.acc += dt;
      while (this.acc >= STEP) { this.step(STEP); this.acc -= STEP; }
      this.orbitCamera(this.level.checkpoints[0].position, 16, 6, 6, dt);
    }
  }

  // ── 메인 루프 ──
  tick() {
    const dt = Math.min(this.clock.getDelta(), 0.05);
    const p = this.p;
    this.input.update(dt);
    const flaps = this.input.consumeFlaps();

    if (this.state === 'playing') {
      this.ctrl.tilt = this.input.tilt;
      this.ctrl.glide = this.input.glide;
      this.levelTime += dt;
      this.level.update(this.levelTime, dt);
      if (p.grounded && p.ground) p.pos.add(p.ground.delta); // 움직이는 발판에 실려 간다
      for (const f of flaps) this.flap(f.strength);

      this.acc += dt;
      let n = 0;
      while (this.acc >= STEP && n < 8) { this.step(STEP); this.acc -= STEP; n++; }
      if (n === 8) this.acc = 0;

      this.stats.time += dt;
      this.checkProgress();
      if (this.state === 'playing') this.updateCamera(dt);
      if (this.state === 'playing' && this.mode === 'camera' && !this.pose.present) this.goAway();
    } else if (this.state === 'away') {
      // 다시 보이고 1초가 지나면 자동으로 이어서
      this.backFor = this.pose.present ? this.backFor + dt : 0;
      this.ui.setAwayBack(this.pose.present, this.backFor);
      if (this.backFor > 1) this.resume();
    } else if (this.state === 'calibrating') {
      // 게임 도중 재캘리브레이션이면 화면을 그대로 멈춰 둔다
      if (!this.calibInGame) this._attract(dt);
      const st = this.pose.calibrationStatus();
      this.ui.updateCalib(st, this.pose.present);
      if (st.done) { const f = this.afterCalib; this.afterCalib = null; this.input.consumeFlaps(); f?.(); }
    } else if (this.state === 'menu' || this.state === 'clear' || this.state === 'loading') {
      this._attract(dt);
    }

    // 새 모델 연출
    const frozen = this.state === 'paused' || this.state === 'away' || (this.state === 'calibrating' && this.calibInGame);
    const live = !frozen;
    const stunned = p.stun > 0;
    const targetRoll = stunned ? 0 : -this.ctrl.tilt * CONFIG.MAX_ROLL; // 왼쪽 기울기 → 왼쪽 날개가 내려감
    p.roll += (targetRoll - p.roll) * damp(8, dt);
    const targetPitch = p.grounded || this.state === 'clear' ? 0 : clamp(p.vel.y * 0.05, -0.55, 0.45);
    p.pitch += (targetPitch - p.pitch) * damp(6, dt);
    this.bird.root.position.copy(p.pos);
    this.bird.root.rotation.y = p.yaw;
    this.bird.update(live ? dt : 0, {
      roll: p.roll, pitch: p.pitch,
      grounded: p.grounded || this.state === 'clear', gliding: p.gliding, spread: p.spread,
      stunned, wingPose: this.input.wingPose,
    });

    // 하늘·조명
    this.level.updateAtmosphere(p.pos.y, { scene: this.scene, sun: this.sun, hemi: this.hemi, stars: this.stars });
    this.stars.position.copy(this.camera.position);
    this.sun.position.copy(p.pos).add(this.sunOffset);
    this.sun.target.position.copy(p.pos);

    if (this.state === 'playing' || frozen) {
      this.ui.update({
        height: p.pos.y, goal: NEST_HEIGHT,
        stamina: p.stamina / CONFIG.STAMINA_MAX, staminaOn: CONFIG.STAMINA_ENABLED,
        tilt: this.ctrl.tilt, gliding: p.gliding, spread: p.spread, stunned, grounded: p.grounded,
        time: this.stats.time, falls: this.stats.falls,
        section: this.level.sectionAt(p.pos.y), checkpoint: this.cpIndex,
      });
    }

    this.renderer.render(this.scene, this.camera);
  }
}

new Game();
window.__gameReady = true;   // index.html 의 실행 진단용
