// ui.js — 메뉴, HUD, 일시정지, 클리어 화면 (DOM)
// 2단계: 카메라 시작, 로딩, 캘리브레이션, 자동 일시정지, 웹캠 창(뼈대 표시)
// 3단계에서 감도 슬라이더·사운드·연출을 더한다.

const $ = (id) => document.getElementById(id);

export class UI {
  constructor({ onStartCamera, onStartKeyboard, onResume, onRestart, onRecalibrate }) {
    this.screens = {
      menu: $('menu'),
      hud: $('hud'),
      pause: $('pause'),
      clear: $('clear'),
      loading: $('loading'),
      calib: $('calib'),
      away: $('away'),
    };
    $('btn-start-cam').addEventListener('click', onStartCamera);
    $('btn-start-key').addEventListener('click', onStartKeyboard);
    $('btn-recalib').addEventListener('click', onRecalibrate);
    $('btn-resume').addEventListener('click', onResume);
    $('btn-restart').addEventListener('click', onRestart);
    $('btn-again').addEventListener('click', onRestart);

    this.el = {
      height: $('alt-now'),
      marker: $('alt-marker'),
      fill: $('alt-fill'),
      time: $('stat-time'),
      falls: $('stat-falls'),
      section: $('stat-section'),
      stamina: $('stamina-fill'),
      staminaBox: $('stamina'),
      tiltDot: $('tilt-dot'),
      flap: $('flap-ind'),
      state: $('flight-state'),
      toast: $('toast'),
      banner: $('banner'),
      bannerNum: $('banner-num'),
      bannerName: $('banner-name'),
      hit: $('hit-flash'),
    };
    this._last = {};
    this._toastTimer = 0;
    this._bannerTimer = 0;
    this.sectionNames = [];
  }

  show(name, { camera = false } = {}) {
    for (const [k, el] of Object.entries(this.screens)) {
      const on = k === name || (k === 'hud' && (name === 'pause' || name === 'away'));
      el.hidden = !on;
    }
    if (name === 'pause') $('btn-recalib').hidden = !camera;
    if (name === 'menu') $('cam-error').hidden = true;
    $('cam').classList.toggle('large', name === 'calib');
    const focus = { menu: 'btn-start-cam', pause: 'btn-resume', clear: 'btn-again' }[name];
    if (focus) requestAnimationFrame(() => $(focus).focus());
  }

  setCamVisible(on) { $('cam').hidden = !on; }
  setLoading(msg) { $('loading-msg').textContent = msg; }

  showCameraError(msg) {
    const e = $('cam-error');
    e.textContent = msg;
    e.hidden = false;
  }

  updateCalib({ progress, message }, present) {
    this._set('cMsg', present ? message : '카메라 앞에 상반신이 보이게 서주세요', (v) => { $('calib-msg').textContent = v; });
    this._set('cP', Math.round(progress * 100), (v) => {
      $('calib-fill').style.width = `${v}%`;
      $('calib-count').textContent = v > 0 ? Math.ceil(3 - (v / 100) * 3) || '✓' : '';
    });
  }

  setAwayBack(present, t) {
    this._set('away', present, (v) => {
      $('away-msg').textContent = v ? '보여요! 곧 이어서 시작해요' : '카메라 앞에 상반신이 보이게 서주세요';
    });
  }

  // 고도 막대에 체크포인트 눈금 (0..1 비율)
  setCheckpointMarks(ratios) {
    const rail = $('alt-rail');
    for (const r of ratios) {
      const t = document.createElement('span');
      t.className = 'alt-tick';
      t.style.bottom = `${r * 100}%`;
      rail.appendChild(t);
    }
  }

  // 값이 바뀔 때만 DOM 을 건드린다
  _set(key, value, fn) {
    if (this._last[key] === value) return;
    this._last[key] = value;
    fn(value);
  }

  update(d) {
    const ratio = Math.min(1, Math.max(0, d.height / d.goal));
    this._set('h', Math.max(0, Math.round(d.height)), (v) => { this.el.height.textContent = v; });
    this._set('hr', Math.round(ratio * 400) / 4, (v) => {
      this.el.marker.style.bottom = `${v}%`;
      this.el.fill.style.height = `${v}%`;
    });
    const sec = Math.floor(d.time);
    this._set('t', sec, (v) => {
      this.el.time.textContent = `${Math.floor(v / 60)}:${String(v % 60).padStart(2, '0')}`;
    });
    this._set('f', d.falls, (v) => { this.el.falls.textContent = v; });
    this._set('s', d.section, (v) => { this.el.section.textContent = `${v + 1}구간`; });

    this._set('stOn', d.staminaOn, (v) => { this.el.staminaBox.hidden = !v; });
    this._set('st', Math.round(d.stamina * 100), (v) => {
      this.el.stamina.style.width = `${v}%`;
      this.el.staminaBox.classList.toggle('low', v < 15);
    });
    this._set('tilt', Math.round(d.tilt * 100), (v) => {
      this.el.tiltDot.style.left = `${50 + v * 0.45}%`;
    });

    const state = d.stunned ? '휘청!' : d.grounded ? '쉬는 중' : d.spread ? '활공 (날개 활짝)' : d.gliding ? '활공' : '날갯짓';
    this._set('state', state, (v) => {
      this.el.state.textContent = v;
      this.el.state.dataset.kind = d.stunned ? 'stun' : d.grounded ? 'rest' : 'fly';
    });
  }

  flashFlap(weak = false) {
    const f = this.el.flap;
    f.classList.remove('on', 'weak');
    void f.offsetWidth;            // 애니메이션 재시작
    f.classList.add('on');
    if (weak) f.classList.add('weak');
  }

  flashHit() {
    const h = this.el.hit;
    h.classList.remove('on');
    void h.offsetWidth;
    h.classList.add('on');
  }

  toast(text, kind = '') {
    const t = this.el.toast;
    t.textContent = text;
    t.dataset.kind = kind;
    t.classList.add('on');
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => t.classList.remove('on'), 1800);
  }

  showSection(name, index) {
    const b = this.el.banner;
    this.el.bannerNum.textContent = `${index + 1}구간`;
    this.el.bannerName.textContent = name;
    b.classList.remove('on');
    void b.offsetWidth;
    b.classList.add('on');
  }

  showClear({ time, falls }) {
    const s = Math.floor(time);
    $('clear-time').textContent = `${Math.floor(s / 60)}분 ${String(s % 60).padStart(2, '0')}초`;
    $('clear-falls').textContent = `${falls}번`;
    this.show('clear');
  }
}
